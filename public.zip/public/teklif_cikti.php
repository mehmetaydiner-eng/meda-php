<?php
/**
 * public/teklif_cikti.php
 * Teklifin yazdırılabilir temiz A4 sayfa çıktısı.
 */

require_once __DIR__ . '/../includes/auth.php';
require_login();

$id = safe_int($_GET['id'] ?? null);
if (!$id) {
    header('Location: ' . BASE_URL . '/teklifler.php');
    exit;
}

$stmt = $pdo->prepare('SELECT * FROM teklifler WHERE id = ?');
$stmt->execute([$id]);
$teklif = $stmt->fetch();
if (!$teklif) {
    http_response_code(404);
    die('Teklif bulunamadı.');
}

$cari = null;
if ($teklif['cari_id']) {
    $stmt = $pdo->prepare('SELECT * FROM cariler WHERE id = ?');
    $stmt->execute([$teklif['cari_id']]);
    $cari = $stmt->fetch();
}

$stmt = $pdo->prepare('SELECT * FROM teklif_detaylari WHERE teklif_id = ?');
$stmt->execute([$id]);
$detaylar = $stmt->fetchAll();

$firma_bilgileri = [
    'unvan'         => 'MEDA BİLGİSAYAR',
    'vergi_no'      => '39292069044',
    'vergi_dairesi' => 'Üçkapılar',
    'adres'         => '82.Sk. Yenice Apt: No:16 07040 Kızılsaray Mh. / Muratpaşa / Antalya',
    'tel'           => '0 (242) 247 6699',
    'website'       => 'www.medabilgisayar.net',
    'email'         => 'mehmetaydiner@gmail.com',
];

$doviz_simge = match($teklif['para_birimi']) {
    'USD' => '$',
    'EUR' => '€',
    default => '₺',
};
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Teklif <?= e($teklif['teklif_no']) ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Times New Roman', serif; background: white; padding: 30px; color: #000; }
        .teklif-container { max-width: 900px; margin: 0 auto; border: 1px solid #000; padding: 35px; position: relative; }
        .teklif-header { display: flex; justify-content: space-between; border-bottom: 2px solid #000; padding-bottom: 15px; margin-bottom: 20px; }
        .teklif-header .firma-bilgi { font-size: 12px; line-height: 1.6; }
        .teklif-header .firma-bilgi strong { font-size: 18px; text-transform: uppercase; }
        .teklif-header .teklif-bilgi { text-align: right; font-size: 12px; line-height: 1.8; }
        .teklif-header .teklif-bilgi .teklif-no { font-size: 20px; font-weight: bold; }
        .teklif-table { width: 100%; font-size: 11px; border-collapse: collapse; margin: 20px 0; }
        .teklif-table th { background: #f5f5f5; padding: 8px 10px; border: 1px solid #000; text-align: left; font-weight: bold; text-transform: uppercase; }
        .teklif-table td { padding: 8px 10px; border: 1px solid #000; }
        .teklif-table .text-end { text-align: right; }
        .teklif-table .text-center { text-align: center; }
        .imza { margin-top: 40px; padding-top: 15px; border-top: 1px solid #000; font-size: 11px; display: flex; justify-content: space-between; }
        .no-print-btn {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #28a745;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            font-weight: bold;
            cursor: pointer;
            z-index: 9999;
            box-shadow: 0 2px 10px rgba(0,0,0,0.3);
        }
        @media print {
            body { padding: 10px; }
            .teklif-container { border: none; }
            .no-print-btn { display: none !important; }
        }
    </style>
</head>
<body>
    <button class="no-print-btn" onclick="window.print()"><i class="fas fa-print"></i> YAZDIR / KAYDET</button>

    <div class="teklif-container">
        <!-- HEADER -->
        <div class="teklif-header">
            <div class="firma-bilgi">
                <strong><?= e($firma_bilgileri['unvan']) ?></strong><br>
                <?= e($firma_bilgileri['adres']) ?><br>
                Tel: <?= e($firma_bilgileri['tel']) ?> | E-Posta: <?= e($firma_bilgileri['email']) ?><br>
                Web: <?= e($firma_bilgileri['website']) ?>
            </div>
            <div class="teklif-bilgi">
                <div class="teklif-no">FİYAT TEKLİFİ</div>
                <div><strong>Teklif No:</strong> <?= e($teklif['teklif_no']) ?></div>
                <div><strong>Tarih:</strong> <?= format_tarih($teklif['teklif_tarihi']) ?></div>
                <div><strong>Geçerlilik:</strong> <?= $teklif['gecerlilik_tarihi'] ? format_tarih($teklif['gecerlilik_tarihi']) : '-' ?></div>
                <?php if ($teklif['teslim_tarihi']): ?>
                    <div><strong>Teslim Tarihi:</strong> <?= format_tarih($teklif['teslim_tarihi']) ?></div>
                <?php endif; ?>
            </div>
        </div>

        <!-- TARAFLAR -->
        <div style="display: flex; gap: 20px; margin-bottom: 20px;">
            <div style="flex: 1; border: 1px solid #000; padding: 12px 15px;">
                <div style="font-weight: bold; font-size: 11px; text-transform: uppercase; border-bottom: 1px solid #000; padding-bottom: 5px; margin-bottom: 8px;">TEKLİF VEREN</div>
                <div style="font-size: 12px; line-height: 1.8;">
                    <strong><?= e($firma_bilgileri['unvan']) ?></strong><br>
                    Vergi Dairesi: <?= e($firma_bilgileri['vergi_dairesi']) ?><br>
                    Vergi/TC Kimlik No: <?= e($firma_bilgileri['vergi_no']) ?><br>
                    Adres: <?= e($firma_bilgileri['adres']) ?>
                </div>
            </div>
            <div style="flex: 1; border: 1px solid #000; padding: 12px 15px;">
                <div style="font-weight: bold; font-size: 11px; text-transform: uppercase; border-bottom: 1px solid #000; padding-bottom: 5px; margin-bottom: 8px;">TEKLİF SUNULAN MÜŞTERİ</div>
                <div style="font-size: 12px; line-height: 1.8;">
                    <strong><?= e($cari['unvan'] ?? '-') ?></strong><br>
                    Vergi Dairesi: <?= e($cari['vergi_dairesi'] ?? '-') ?><br>
                    Vergi/TC Kimlik No: <?= e($cari['vergi_no'] ?? '-') ?><br>
                    Adres: <?= e($cari['adres'] ?? '-') ?><br>
                    Tel: <?= e($cari['telefon'] ?? '-') ?> | E-Posta: <?= e($cari['email'] ?? '-') ?>
                </div>
            </div>
        </div>

        <div style="margin-bottom: 15px; font-size: 12px; line-height: 1.6;">
            <strong>Konu:</strong> <?= e($teklif['konu']) ?>
        </div>

        <!-- KALEMLER TABLOSU -->
        <table class="teklif-table">
            <thead>
                <tr>
                    <th style="width: 30px;">#</th>
                    <th>AÇIKLAMA / MAL HİZMET TANIMI</th>
                    <th style="width: 10%;" class="text-center">MİKTAR</th>
                    <th style="width: 15%;" class="text-end">BİRİM FİYAT</th>
                    <th style="width: 10%;" class="text-end">İSKONTO</th>
                    <th style="width: 10%;" class="text-center">KDV</th>
                    <th style="width: 18%;" class="text-end">TOPLAM TUTAR</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($detaylar as $i => $detay): ?>
                <tr>
                    <td class="text-center"><?= $i + 1 ?></td>
                    <td>
                        <strong><?= e($detay['urun_adi']) ?></strong>
                        <?php if ($detay['urun_kodu']): ?>
                            <br><small style="color:#555;">KOD: <?= e($detay['urun_kodu']) ?></small>
                        <?php endif; ?>
                    </td>
                    <td class="text-center"><?= number_format((float)$detay['miktar'], 2, ',', '.') ?></td>
                    <td class="text-end"><?= number_format((float)$detay['birim_fiyati'], 2, ',', '.') ?> <?= $doviz_simge ?></td>
                    <td class="text-end"><?= number_format((float)$detay['iskonto'], 0, ',', '.') ?>%</td>
                    <td class="text-center">%<?= number_format((float)$detay['vergi_orani'], 0, ',', '.') ?></td>
                    <td class="text-end"><strong><?= number_format((float)$detay['toplam_tutar'], 2, ',', '.') ?></strong> <?= $doviz_simge ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="6" class="text-end"><strong>ARA TOPLAM</strong></td>
                    <td class="text-end"><?= number_format((float)$teklif['ara_toplam'], 2, ',', '.') ?> <?= $doviz_simge ?></td>
                </tr>
                <tr>
                    <td colspan="6" class="text-end"><strong>TOPLAM İSKONTO</strong></td>
                    <td class="text-end">-<?= number_format((float)$teklif['iskonto_tutari'], 2, ',', '.') ?> <?= $doviz_simge ?></td>
                </tr>
                <tr>
                    <td colspan="6" class="text-end"><strong>TOPLAM KDV</strong></td>
                    <td class="text-end"><?= number_format((float)$teklif['vergi_tutari'], 2, ',', '.') ?> <?= $doviz_simge ?></td>
                </tr>
                <tr style="border-top: 2px solid #000; font-size: 14px;">
                    <td colspan="6" class="text-end"><strong>GENEL TOPLAM</strong></td>
                    <td class="text-end"><strong><?= number_format((float)$teklif['genel_toplam'], 2, ',', '.') ?> <?= $doviz_simge ?></strong></td>
                </tr>
            </tfoot>
        </table>

        <!-- AÇIKLAMA / KOŞULLAR -->
        <?php if (!empty($teklif['aciklama'])): ?>
        <div style="margin-top: 20px; font-size: 11px; border: 1px solid #ccc; padding: 10px 15px; line-height: 1.6;">
            <strong>TEKLİF KOŞULLARI VE AÇIKLAMALAR:</strong><br>
            <?= nl2br(e($teklif['aciklama'])) ?>
        </div>
        <?php endif; ?>

        <!-- ONAY BİLGİSİ -->
        <?php if ($teklif['durum'] === 'ONAYLANDI'): ?>
        <div style="margin-top: 15px; font-size: 11px; color: green; border: 1px solid green; padding: 8px 12px; display:inline-block; font-weight:bold;">
            <i class="fas fa-check-circle"></i> BU TEKLİF MÜŞTERİ TARAFINDAN ONAYLANMIŞTIR.<br>
            Onaylayan Yetkili: <?= e($teklif['onaylayan']) ?> | Tarih: <?= format_tarih($teklif['onay_tarihi'], 'd.m.Y H:i') ?>
        </div>
        <?php endif; ?>

        <!-- IMZA ALANI -->
        <div class="imza">
            <div>
                <strong>TEKLİF HAZIRLAYAN</strong><br>
                <?= e($firma_bilgileri['unvan']) ?><br>
                İmza / Kaşe
            </div>
            <div>
                <strong>TEKLİFİ ALAN / ONAYLAYAN</strong><br>
                <?= e($cari['unvan'] ?? '-') ?><br>
                İmza
            </div>
        </div>
    </div>
</body>
</html>
