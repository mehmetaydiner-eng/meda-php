<?php
require_once __DIR__ . '/../includes/auth.php';
require_login();
require_csrf(BASE_URL . '/stok_listesi.php');

$id = safe_int($_GET['id'] ?? null);
if (!$id) {
    header('Location: ' . BASE_URL . '/stok_listesi.php');
    exit;
}

$stmt = $pdo->prepare('SELECT * FROM urunler WHERE id = ?');
$stmt->execute([$id]);
$urun = $stmt->fetch();

if (!$urun) {
    http_response_code(404);
    die('Ürün bulunamadı.');
}

if (empty($urun['barkod'])) {
    $yeniBarkod = generate_barkod();
    $update = $pdo->prepare('UPDATE urunler SET barkod = ?, updated_at = datetime(\'now\',\'localtime\') WHERE id = ?');
    $update->execute([$yeniBarkod, $id]);
    flash_set('Barkod oluşturuldu: ' . $yeniBarkod, 'success');
} else {
    flash_set('Mevcut barkod: ' . $urun['barkod'], 'info');
}

header('Location: ' . BASE_URL . '/stok_duzenle.php?id=' . $id);
exit;
