<?php
/**
 * public/teklif_durum.php
 * Teklif durumunu (TASLAK, BEKLEMEDE, ONAYLANDI, REDDEDILDI) günceller.
 */

require_once __DIR__ . '/../includes/auth.php';
require_login();
require_csrf(BASE_URL . '/teklifler.php');

$user = current_user();
$id = safe_int($_GET['id'] ?? null);
$durum = temizle_text($_GET['durum'] ?? '');

$allowed_status = ['TASLAK', 'BEKLEMEDE', 'ONAYLANDI', 'REDDEDILDI'];

if (!$id || !in_array($durum, $allowed_status)) {
    flash_set('Geçersiz teklif veya durum parametresi!', 'danger');
    header('Location: ' . BASE_URL . '/teklifler.php');
    exit;
}

$stmt = $pdo->prepare('SELECT * FROM teklifler WHERE id = ?');
$stmt->execute([$id]);
$teklif = $stmt->fetch();

if (!$teklif) {
    http_response_code(404);
    die('Teklif bulunamadı.');
}

$onay_tarihi = null;
$onaylayan = null;

if ($durum === 'ONAYLANDI') {
    $onay_tarihi = date('Y-m-d H:i:s');
    $onaylayan = $user['username'];
}

try {
    $stmt = $pdo->prepare('
        UPDATE teklifler 
        SET durum = ?, onay_tarihi = ?, onaylayan = ?, updated_at = datetime(\'now\',\'localtime\') 
        WHERE id = ?
    ');
    $stmt->execute([$durum, $onay_tarihi, $onaylayan, $id]);

    flash_set("{$teklif['teklif_no']} numaralı teklif durumu '{$durum}' olarak güncellendi.", 'success');
} catch (PDOException $e) {
    flash_set("Teklif durumu güncellenirken hata oluştu: " . $e->getMessage(), 'danger');
}

header('Location: ' . BASE_URL . '/teklifler.php');
exit;
