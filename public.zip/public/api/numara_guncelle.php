<?php
/**
 * NOT: Orijinal Flask route'u da (api_numara_guncelle) sadece verilen numarayı
 * int()'e çevirip çakışma kontrolü yapıyordu; hiçbir yere KALICI olarak
 * yazmıyordu (öyle bir "sıradaki numara" tablosu/alanı hiç yoktu). Yani
 * "MED2026000000053" gibi tam formatlı bir numara (rakam olmayan harfler
 * içerdiği için) gönderildiğinde orijinalde de int() dönüşümü patlıyor ve
 * hata dönüyordu. Burada da aynı davranış korundu - sadece SAF SAYI
 * (örn. "53") gönderilirse anlamlı bir kontrol yapılabiliyor.
 */
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/numara_manager.php';
require_login();

header('Content-Type: application/json; charset=utf-8');

try {
    $data = json_decode(file_get_contents('php://input'), true) ?? [];
    require_csrf_json($data['csrf_token'] ?? null);

    $prefix = $data['prefix'] ?? null;
    $yeniNumaraRaw = $data['yeni_numara'] ?? null;

    if (!$prefix || !$yeniNumaraRaw) {
        echo json_encode(['success' => false, 'message' => 'Prefix ve numara gerekli!'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // Sadece SAF SAYI kabul ediyoruz (örn. "53") - bu alan bizim kendi
    // otomatik sıra numaralandırma sistemimizin başlangıç değeridir, harf
    // içeren tam formatlı bir numara (örn. "MED2026000000053") ya da
    // tedarikçi fatura numarası burada geçerli değildir.
    $trimmed = trim((string)$yeniNumaraRaw);
    if (!ctype_digit($trimmed)) {
        echo json_encode([
            'success' => false,
            'message' => "Bu alana sadece SAF SAYI girilebilir (örn. 53) - '{$trimmed}' geçerli bir sayı değil.",
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    [$success, $message] = NumaraManager::setNext($pdo, $prefix, (int)$trimmed);

    if ($success) {
        echo json_encode(['success' => true, 'message' => "Numara güncellendi: {$trimmed}"], JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode(['success' => false, 'message' => $message], JSON_UNESCAPED_UNICODE);
    }
} catch (Throwable $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
