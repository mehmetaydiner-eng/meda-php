<?php
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/numara_manager.php';
require_login();

header('Content-Type: application/json; charset=utf-8');

try {
    $data = json_decode(file_get_contents('php://input'), true) ?? [];
    require_csrf_json($data['csrf_token'] ?? null);

    $prefix = $data['prefix'] ?? null;
    $yeniNumara = (int)($data['yeni_numara'] ?? 0);

    if ($yeniNumara < 1) {
        echo json_encode(['success' => false, 'message' => "Numara 1'den küçük olamaz!"], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if (!$prefix) {
        echo json_encode(['success' => false, 'message' => 'Geçersiz prefix!'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    [$success, $message] = NumaraManager::setNext($pdo, $prefix, $yeniNumara);
    echo json_encode(['success' => $success, 'message' => $message], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
