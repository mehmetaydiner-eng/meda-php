<?php
require_once __DIR__ . '/../includes/auth.php';
require_login();

// Efe'nin isteği üzerine (19 Temmuz 2026): kategori artık serbest metin
// değil, kategori_yonetim.php'de tanımlanan listeden bir dropdown.
$kategoriler = $pdo->query('SELECT kategori_adi FROM kategoriler ORDER BY kategori_adi')->fetchAll(PDO::FETCH_COLUMN);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf(BASE_URL . '/stok_ekle.php');

    $urun_kodu = turkce_upper(trim($_POST['urun_kodu'] ?? ''));
    $urun_adi  = turkce_upper(trim($_POST['urun_adi'] ?? ''));
    $barkod    = trim($_POST['barkod'] ?? '');
    $seri_no   = turkce_upper(trim($_POST['seri_no'] ?? ''));
    $urun_tipi = turkce_upper(trim($_POST['urun_tipi'] ?? 'SIFIR'));
    $kategori  = turkce_upper(trim($_POST['kategori'] ?? ''));
    $birim     = turkce_upper(trim($_POST['birim'] ?? 'ADET'));

    $alis_fiyati        = safe_float($_POST['alis_fiyati'] ?? null);
    $alis_fiyati_doviz  = turkce_upper(trim($_POST['alis_fiyati_doviz'] ?? 'TL'));
    $satis_fiyati       = safe_float($_POST['satis_fiyati'] ?? null);
    $satis_fiyati_doviz = turkce_upper(trim($_POST['satis_fiyati_doviz'] ?? 'TL'));
    $stok_miktari       = safe_float($_POST['stok_miktari'] ?? null);
    $min_stok           = safe_float($_POST['min_stok'] ?? null);
    $max_stok           = safe_float($_POST['max_stok'] ?? null);
    $aciklama           = turkce_upper(trim($_POST['aciklama'] ?? ''));

    if ($barkod === '') {
        $barkod = generate_barkod();
    }

    if ($urun_kodu === '') {
        flash_set('Ürün kodu zorunludur!', 'danger');
        header('Location: ' . BASE_URL . '/stok_ekle.php');
        exit;
    }
    if ($urun_adi === '') {
        flash_set('Ürün adı zorunludur!', 'danger');
        header('Location: ' . BASE_URL . '/stok_ekle.php');
        exit;
    }

    $stmt = $pdo->prepare('SELECT id FROM urunler WHERE urun_kodu = ?');
    $stmt->execute([$urun_kodu]);
    if ($stmt->fetch()) {
        flash_set('Bu ürün kodu zaten kullanılıyor!', 'danger');
        header('Location: ' . BASE_URL . '/stok_ekle.php');
        exit;
    }

    if ($barkod !== '') {
        $stmt = $pdo->prepare('SELECT id FROM urunler WHERE barkod = ?');
        $stmt->execute([$barkod]);
        if ($stmt->fetch()) {
            flash_set('Bu barkod zaten kullanılıyor!', 'danger');
            header('Location: ' . BASE_URL . '/stok_ekle.php');
            exit;
        }
    }

    $insert = $pdo->prepare(
        'INSERT INTO urunler
            (urun_kodu, urun_adi, barkod, seri_no, urun_tipi, kategori, birim,
             alis_fiyati, alis_fiyati_doviz, satis_fiyati, satis_fiyati_doviz,
             stok_miktari, min_stok, max_stok, aciklama, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime(\'now\',\'localtime\'), datetime(\'now\',\'localtime\'))'
    );
    $insert->execute([
        $urun_kodu, $urun_adi, $barkod, $seri_no, $urun_tipi, $kategori, $birim,
        $alis_fiyati, $alis_fiyati_doviz, $satis_fiyati, $satis_fiyati_doviz,
        $stok_miktari, $min_stok, $max_stok, $aciklama,
    ]);

    $yeniUrunId = (int)$pdo->lastInsertId();

    if ($stok_miktari > 0) {
        stok_hareketi_ekle(
            $pdo, $yeniUrunId, 'MANUEL', $stok_miktari,
            0, $stok_miktari, null, 'İlk stok girişi (ürün oluşturulurken)'
        );
    }

    // Ürün resmi (opsiyonel) - kullanıcı dosya seçmediyse sessizce atlanır
    if (!empty($_FILES['urun_resmi']['name'])) {
        $yukleSonuc = urun_resim_yukle($_FILES['urun_resmi'], $yeniUrunId);
        if ($yukleSonuc['success'] && $yukleSonuc['filename']) {
            $pdo->prepare('UPDATE urunler SET resim = ? WHERE id = ?')->execute([$yukleSonuc['filename'], $yeniUrunId]);
        } elseif (!$yukleSonuc['success']) {
            flash_set($urun_adi . ' eklendi, ama resim yüklenemedi: ' . $yukleSonuc['message'], 'warning');
            header('Location: ' . BASE_URL . '/stok_listesi.php');
            exit;
        }
    }

    flash_set($urun_adi . ' başarıyla eklendi!', 'success');
    header('Location: ' . BASE_URL . '/stok_listesi.php');
    exit;
}

$page_title   = 'YENİ ÜRÜN EKLE';
$breadcrumb   = 'Ürün Ekleme';
$current_page = 'stok_ekle';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-10">
        <div class="card-custom">
            <div class="card-header-custom">
                <h5><i class="fas fa-box"></i> YENİ ÜRÜN EKLE</h5>
                <a href="<?= BASE_URL ?>/stok_listesi.php" class="btn btn-outline-primary btn-sm">
                    <i class="fas fa-arrow-left"></i> GERİ
                </a>
            </div>

            <form method="POST" enctype="multipart/form-data">
                <?= csrf_field() ?>                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">ÜRÜN KODU <span class="text-danger">*</span></label>
                        <input type="text" name="urun_kodu" class="form-control" placeholder="PR-001" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">ÜRÜN ADI <span class="text-danger">*</span></label>
                        <input type="text" name="urun_adi" class="form-control" placeholder="LAPTOP" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">BARKOD</label>
                        <div class="input-group">
                            <input type="text" name="barkod" id="barkod" class="form-control" placeholder="OTOMATİK OLUŞTURULACAK">
                            <button type="button" class="btn btn-outline-primary" onclick="barkodOlustur()">
                                <i class="fas fa-qrcode"></i> OLUŞTUR
                            </button>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">SERİ NUMARASI</label>
                        <input type="text" name="seri_no" class="form-control" placeholder="SN-2024-001">
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">
                            KATEGORİ
                            <a href="<?= BASE_URL ?>/kategori_yonetim.php" target="_blank" style="font-size: 11px;" title="Yeni kategori tanımla">
                                <i class="fas fa-plus-circle"></i> Kategori Ekle/Yönet
                            </a>
                        </label>
                        <select name="kategori" class="form-select">
                            <option value="">-- Kategori Seçin --</option>
                            <?php foreach ($kategoriler as $kat): ?>
                                <option value="<?= e($kat) ?>"><?= e($kat) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <?php if (!$kategoriler): ?>
                            <small class="text-warning">Henüz kategori tanımlanmamış. <a href="<?= BASE_URL ?>/kategori_yonetim.php" target="_blank">Buradan ekleyebilirsiniz</a>.</small>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">BİRİM</label>
                        <select name="birim" class="form-select">
                            <option value="ADET">ADET</option>
                            <option value="KG">KG</option>
                            <option value="METRE">METRE</option>
                            <option value="LİTRE">LİTRE</option>
                            <option value="SAAT">SAAT</option>
                            <option value="PAKET">PAKET</option>
                            <option value="KUTU">KUTU</option>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">ÜRÜN TİPİ</label>
                        <select name="urun_tipi" class="form-select">
                            <option value="SIFIR">SIFIR</option>
                            <option value="2.EL">2.EL</option>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">ALIŞ FİYATI</label>
                        <div class="input-group">
                            <input type="number" name="alis_fiyati" class="form-control" step="0.01" value="0">
                            <select name="alis_fiyati_doviz" class="form-select" style="max-width: 80px;">
                                <option value="TL">TL</option>
                                <option value="USD">USD</option>
                                <option value="EUR">EUR</option>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">SATIŞ FİYATI</label>
                        <div class="input-group">
                            <input type="number" name="satis_fiyati" class="form-control" step="0.01" value="0">
                            <select name="satis_fiyati_doviz" class="form-select" style="max-width: 80px;">
                                <option value="TL">TL</option>
                                <option value="USD">USD</option>
                                <option value="EUR">EUR</option>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">STOK MİKTARI</label>
                        <input type="number" name="stok_miktari" class="form-control" step="0.01" value="0">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">MIN. STOK</label>
                        <input type="number" name="min_stok" class="form-control" step="0.01" value="0">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">MAX. STOK</label>
                        <input type="number" name="max_stok" class="form-control" step="0.01" value="0">
                    </div>

                    <div class="col-md-12">
                        <label class="form-label">ÜRÜN RESMİ</label>
                        <input type="file" name="urun_resmi" class="form-control" accept="image/jpeg,image/png,image/webp,image/gif">
                        <small class="text-muted">JPG, PNG, WEBP ya da GIF - maksimum 3 MB (opsiyonel).</small>
                    </div>
                    <div class="col-md-12">
                        <label class="form-label">AÇIKLAMA</label>
                        <textarea name="aciklama" class="form-control" rows="3" placeholder="ÜRÜN AÇIKLAMASI..."></textarea>
                    </div>
                </div>

                <div class="mt-4">
                    <button type="submit" class="btn btn-success-custom">
                        <i class="fas fa-save"></i> KAYDET
                    </button>
                    <a href="<?= BASE_URL ?>/stok_listesi.php" class="btn btn-outline-primary">İPTAL</a>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
$extra_js = <<<'JS'
<script>
function barkodOlustur() {
    var prefix = '869';
    var random = '';
    for (var i = 0; i < 9; i++) {
        random += Math.floor(Math.random() * 10);
    }
    var check = Math.floor(Math.random() * 10);
    var barkod = prefix + random + check;
    document.getElementById('barkod').value = barkod;
}
</script>
JS;
require_once __DIR__ . '/../includes/footer.php';
?>
