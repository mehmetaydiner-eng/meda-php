<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/numara_manager.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ' . BASE_URL . '/tahsilat_makbuzu.php');
    exit;
}

require_csrf(BASE_URL . '/tahsilat_makbuzu.php');

try {
    $cari_id = safe_int($_POST['cari_id'] ?? null, 0) ?: null;
    $hesap_id = safe_int($_POST['hesap_id'] ?? null, 0) ?: null;
    $tutar = safe_float($_POST['tutar'] ?? null);
    $odeme_turu = trim($_POST['odeme_turu'] ?? 'NAKİT'); // sabit select değeri, turkce_upper uygulanmıyor (İ/I hatasını önlemek için)
    $para_birimi = turkce_upper(trim($_POST['para_birimi'] ?? 'TRY'));
    $aciklama = turkce_upper(trim($_POST['aciklama'] ?? ''));
    $referans_no = turkce_upper(trim($_POST['referans_no'] ?? ''));
    $tarih_str = trim($_POST['tarih'] ?? '');

    if (!$cari_id) {
        flash_set('Lütfen bir cari seçin!', 'danger');
        header('Location: ' . BASE_URL . '/tahsilat_makbuzu.php');
        exit;
    }
    if ($tutar <= 0) {
        flash_set("Tutar 0'dan büyük olmalıdır!", 'danger');
        header('Location: ' . BASE_URL . '/tahsilat_makbuzu.php');
        exit;
    }

    $tarih = $tarih_str !== '' ? $tarih_str . ' ' . date('H:i:s') : date('Y-m-d H:i:s');

    $stmt = $pdo->prepare('SELECT * FROM cariler WHERE id = ?');
    $stmt->execute([$cari_id]);
    $cari = $stmt->fetch();
    if (!$cari) {
        flash_set('Seçilen cari bulunamadı!', 'danger');
        header('Location: ' . BASE_URL . '/tahsilat_makbuzu.php');
        exit;
    }

    $hesap = null;
    if ($hesap_id) {
        $stmt = $pdo->prepare('SELECT * FROM hesaplar WHERE id = ?');
        $stmt->execute([$hesap_id]);
        $hesap = $stmt->fetch();
    }

    $pdo->beginTransaction();

    $makbuz_no = generate_makbuz_no_nm($pdo, 'TAHSILAT');

    $insert = $pdo->prepare(
        'INSERT INTO makbuzlar
            (makbuz_no, makbuz_tarihi, makbuz_turu, cari_id, hesap_id, ara_toplam, iskonto,
             iskonto_tutari, vergi_orani, vergi_tutari, genel_toplam, para_birimi, odeme_turu,
             aciklama, notlar, durum, created_by, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, 0, 0, 0, 0, ?, ?, ?, ?, ?, ?, ?, datetime(\'now\',\'localtime\'), datetime(\'now\',\'localtime\'))'
    );
    $insert->execute([
        $makbuz_no, $tarih, 'TAHSILAT', $cari_id, $hesap_id, $tutar,
        $tutar, $para_birimi, $odeme_turu, $aciklama, $referans_no, 'OLUŞTURULDU',
        current_user()['username'] ?? '',
    ]);
    $makbuz_id = (int)$pdo->lastInsertId();

    // Tahsilat = cari borcunu azaltır
    $cariBakiyeOncesi = (float)$cari['bakiye'];
    $cariBakiyeSonrasi = $cariBakiyeOncesi - $tutar;
    $pdo->prepare('UPDATE cariler SET bakiye = ? WHERE id = ?')->execute([$cariBakiyeSonrasi, $cari_id]);

    if ($hesap) {
        $yeniHesapBakiye = (float)$hesap['bakiye'] + $tutar;
        $pdo->prepare('UPDATE hesaplar SET bakiye = ? WHERE id = ?')->execute([$yeniHesapBakiye, $hesap_id]);
    }

    $insertHareket = $pdo->prepare(
        'INSERT INTO hesap_hareketleri
            (cari_id, hesap_id, hareket_no, hareket_tarihi, islem_turu, hareket_turu, tutar,
             para_birimi, aciklama, referans_no, odeme_turu, cari_bakiye_oncesi, cari_bakiye_sonrasi, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime(\'now\',\'localtime\'))'
    );
    $insertHareket->execute([
        $cari_id, $hesap_id, generate_hareket_no(), $tarih, 'GİRİŞ', 'TAHSİLAT', $tutar,
        $para_birimi, $aciklama, $referans_no, $odeme_turu, $cariBakiyeOncesi, $cariBakiyeSonrasi,
    ]);

    $pdo->commit();

    flash_set('Tahsilat makbuzu başarıyla oluşturuldu! No: ' . $makbuz_no, 'success');
    header('Location: ' . BASE_URL . '/makbuz_detay.php?id=' . $makbuz_id);
    exit;

} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    flash_set('Hata oluştu: ' . $e->getMessage(), 'danger');
    header('Location: ' . BASE_URL . '/tahsilat_makbuzu.php');
    exit;
}
