<?php
/**
 * public/teklif_kaydet.php
 * Teklif ekleme ve güncelleme işlemlerini transactional olarak işleyen backend dosyası.
 * AJAX POST ile çalışır, JSON döner.
 */

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/numara_manager.php';
require_login();
require_csrf_json();

header('Content-Type: application/json; charset=utf-8');

try {
    $user = current_user();

    $teklif_id_existing = safe_int($_POST['teklif_id'] ?? null, 0) ?: null;
    $teklif_no          = trim($_POST['teklif_no'] ?? '');
    $teklif_tarihi_str  = trim($_POST['teklif_tarihi'] ?? '');
    $teklif_turu        = trim($_POST['teklif_turu'] ?? 'VERILEN');
    $teklif_tipi        = trim($_POST['teklif_tipi'] ?? 'STANDART');
    $cari_id            = safe_int($_POST['cari_id'] ?? null, 0) ?: null;
    $teknik_servis_id   = safe_int($_POST['teknik_servis_id'] ?? null, 0) ?: null;
    $konu               = trim($_POST['konu'] ?? '');
    $aciklama           = trim($_POST['aciklama'] ?? '');
    $notlar             = trim($_POST['notlar'] ?? '');
    $para_birimi        = trim($_POST['para_birimi'] ?? 'TRY');
    $gecerlilik_str     = trim($_POST['gecerlilik_tarihi'] ?? '');
    $teslim_str         = trim($_POST['teslim_tarihi'] ?? '');
    $durum              = trim($_POST['durum'] ?? 'TASLAK');

    if (empty($konu)) {
        echo json_encode(['success' => false, 'message' => 'Teklif konusu boş olamaz!'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if (!$cari_id) {
        echo json_encode(['success' => false, 'message' => 'Lütfen geçerli bir müşteri (cari) seçin!'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // Teklif no yoksa otomatik oluştur
    if (empty($teklif_no)) {
        $teklif_no = generate_teklif_no_nm($pdo, in_array($teklif_turu, ['VERILEN', 'ALINAN'], true) ? $teklif_turu : 'VERILEN');
    }

    // Aynı teklif no kontrolü (kendi hariç)
    $stmt = $pdo->prepare('SELECT id FROM teklifler WHERE teklif_no = ?');
    $stmt->execute([$teklif_no]);
    $existing = $stmt->fetch();
    if ($existing && (!$teklif_id_existing || (int)$existing['id'] !== $teklif_id_existing)) {
        echo json_encode([
            'success' => false,
            'message' => 'Bu teklif numarası zaten kullanılıyor! Mevcut Teklif: ' . $teklif_no,
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $teklif_tarihi = !empty($teklif_tarihi_str) ? $teklif_tarihi_str . ' ' . date('H:i:s') : date('Y-m-d H:i:s');
    $gecerlilik_tarihi = !empty($gecerlilik_str) ? $gecerlilik_str . ' 23:59:59' : null;
    $teslim_tarihi = !empty($teslim_str) ? $teslim_str . ' 23:59:59' : null;

    $pdo->beginTransaction();

    if ($teklif_id_existing) {
        // Güncelleme
        $stmt = $pdo->prepare('
            UPDATE teklifler 
            SET teklif_no = ?, teklif_tarihi = ?, teklif_turu = ?, teklif_tipi = ?, 
                cari_id = ?, teknik_servis_id = ?, konu = ?, aciklama = ?, notlar = ?, 
                para_birimi = ?, gecerlilik_tarihi = ?, teslim_tarihi = ?, durum = ?, 
                updated_at = datetime(\'now\',\'localtime\')
            WHERE id = ?
        ');
        $stmt->execute([
            $teklif_no, $teklif_tarihi, $teklif_turu, $teklif_tipi, 
            $cari_id, $teknik_servis_id, $konu, $aciklama, $notlar, 
            $para_birimi, $gecerlilik_tarihi, $teslim_tarihi, $durum, 
            $teklif_id_existing
        ]);
        $teklif_id = $teklif_id_existing;

        // Eski detayları temizle
        $stmt = $pdo->prepare('DELETE FROM teklif_detaylari WHERE teklif_id = ?');
        $stmt->execute([$teklif_id]);
    } else {
        // Yeni Kayıt
        $stmt = $pdo->prepare('
            INSERT INTO teklifler 
                (teklif_no, teklif_tarihi, teklif_turu, teklif_tipi, cari_id, teknik_servis_id, 
                 konu, aciklama, notlar, para_birimi, gecerlilik_tarihi, teslim_tarihi, 
                 durum, created_by, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime(\'now\',\'localtime\'), datetime(\'now\',\'localtime\'))
        ');
        $stmt->execute([
            $teklif_no, $teklif_tarihi, $teklif_turu, $teklif_tipi, $cari_id, $teknik_servis_id,
            $konu, $aciklama, $notlar, $para_birimi, $gecerlilik_tarihi, $teslim_tarihi,
            $durum, $user['username']
        ]);
        $teklif_id = (int)$pdo->lastInsertId();
    }

    // Detay kalemlerini al ve ekle
    $urun_adi_list = $_POST['urun_adi'] ?? [];
    $miktar_list   = $_POST['miktar'] ?? [];
    $fiyat_list    = $_POST['fiyat'] ?? [];
    $iskonto_list  = $_POST['iskonto'] ?? [];
    $kdv_list      = $_POST['kdv'] ?? [];

    $ara_toplam = 0.0;
    $toplam_iskonto = 0.0;
    $toplam_kdv = 0.0;

    for ($i = 0; $i < count($urun_adi_list); $i++) {
        if (trim($urun_adi_list[$i] ?? '') === '') continue;

        $urun_adi    = turkce_upper(trim($urun_adi_list[$i]));
        $miktar      = safe_float($miktar_list[$i] ?? 1, 1);
        $birim_fiyat = safe_float($fiyat_list[$i] ?? 0, 0);
        $iskonto     = safe_float($iskonto_list[$i] ?? 0, 0);
        $kdv_orani   = safe_float($kdv_list[$i] ?? 18, 18);

        // Ürünü kontrol et, yoksa ekle
        $stmt = $pdo->prepare('SELECT * FROM urunler WHERE urun_adi = ? OR urun_kodu = ? LIMIT 1');
        $stmt->execute([$urun_adi, $urun_adi]);
        $urun = $stmt->fetch();

        if (!$urun) {
            $yeniKod = 'PR-' . date('YmdHis') . '-' . random_int(1000, 9999) . '-' . $i; // çakışmayı önlemek için rastgele bileşen eklendi
            $insertUrun = $pdo->prepare('
                INSERT INTO urunler (urun_kodu, urun_adi, urun_tipi, birim, alis_fiyati, satis_fiyati, stok_miktari, created_at, updated_at)
                VALUES (?, ?, \'SIFIR\', \'ADET\', ?, ?, 0, datetime(\'now\',\'localtime\'), datetime(\'now\',\'localtime\'))
            ');
            $insertUrun->execute([$yeniKod, $urun_adi, $birim_fiyat * 0.8, $birim_fiyat]);
            $urun_id = (int)$pdo->lastInsertId();
            $urun_kodu = $yeniKod;
            $barkod = null;
        } else {
            $urun_id   = (int)$urun['id'];
            $urun_kodu = $urun['urun_kodu'];
            $barkod    = $urun['barkod'];
        }

        $satir_toplam   = $miktar * $birim_fiyat;
        $iskonto_tutar  = $satir_toplam * ($iskonto / 100);
        $matrah         = $satir_toplam - $iskonto_tutar;
        $kdv_tutar      = $matrah * ($kdv_orani / 100);
        $toplam_tutar   = $matrah + $kdv_tutar;

        $ara_toplam     += $satir_toplam;
        $toplam_iskonto += $iskonto_tutar;
        $toplam_kdv     += $kdv_tutar;

        $insertDetay = $pdo->prepare('
            INSERT INTO teklif_detaylari
                (teklif_id, urun_id, urun_adi, urun_kodu, barkod, birim, miktar, birim_fiyati, 
                 iskonto, iskonto_tutari, vergi_orani, vergi_tutari, ara_toplam, toplam_tutar, created_at)
            VALUES (?, ?, ?, ?, ?, \'ADET\', ?, ?, ?, ?, ?, ?, ?, ?, datetime(\'now\',\'localtime\'))
        ');
        $insertDetay->execute([
            $teklif_id, $urun_id, $urun_adi, $urun_kodu, $barkod, $miktar, $birim_fiyat,
            $iskonto, $iskonto_tutar, $kdv_orani, $kdv_tutar, $satir_toplam, $toplam_tutar
        ]);
    }

    $genel_toplam = $ara_toplam - $toplam_iskonto + $toplam_kdv;
    $iskonto_orani_ort = $ara_toplam > 0 ? ($toplam_iskonto / $ara_toplam * 100) : 0;

    // Teklif toplamlarını güncelle
    $updateTeklif = $pdo->prepare('
        UPDATE teklifler 
        SET ara_toplam = ?, iskonto = ?, iskonto_tutari = ?, vergi_orani = 18, vergi_tutari = ?, genel_toplam = ? 
        WHERE id = ?
    ');
    $updateTeklif->execute([$ara_toplam, $iskonto_orani_ort, $toplam_iskonto, $toplam_kdv, $genel_toplam, $teklif_id]);

    $pdo->commit();

    echo json_encode([
        'success'   => true,
        'message'   => 'Teklif başarıyla kaydedildi!',
        'teklif_id' => $teklif_id,
        'teklif_no' => $teklif_no,
    ], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => 'Hata: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
