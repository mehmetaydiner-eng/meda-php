<?php
/**
 * public/stok_barkod_bas.php
 *
 * NOT: Orijinal Flask uygulamasında bu route (/stok/barkod-bas/<id>) mevcuttu
 * ancak render_template('stok_barkod.html', ...) çağırdığı şablon dosyası
 * arşivde YOKTU - yani orijinal uygulamada bu bağlantıya tıklamak sunucu
 * hatasıyla (500) sonuçlanıyordu. Burada onun yerine gerçek, okutulabilir
 * bir barkod (CODE128) üreten bir etiket sayfası eklendi. Barkod, JsBarcode
 * (ücretsiz, açık kaynak JS kütüphanesi, CDN üzerinden) ile SVG olarak
 * render ediliyor - sunucu tarafında görsel üretmeye gerek yok.
 */

require_once __DIR__ . '/../includes/auth.php';
require_login();

$id = safe_int($_GET['id'] ?? null);
if (!$id) {
    header('Location: ' . BASE_URL . '/stok_listesi.php');
    exit;
}

$stmt = $pdo->prepare('SELECT * FROM urunler WHERE id = ?');
$stmt->execute([$id]);
$urun = $stmt->fetch();

if (!$urun) {
    http_response_code(404);
    die('Ürün bulunamadı.');
}

$page_title   = 'BARKOD YAZDIR';
$breadcrumb   = 'Barkod Etiketi';
$current_page = 'stok_duzenle';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card-custom">
            <div class="card-header-custom">
                <h5><i class="fas fa-barcode"></i> BARKOD ETİKETİ</h5>
                <div>
                    <button class="btn btn-primary-custom btn-sm" onclick="window.print()">
                        <i class="fas fa-print"></i> YAZDIR
                    </button>
                    <a href="<?= BASE_URL ?>/stok_duzenle.php?id=<?= (int)$urun['id'] ?>" class="btn btn-outline-primary btn-sm">
                        <i class="fas fa-arrow-left"></i> GERİ
                    </a>
                </div>
            </div>

            <div class="text-center py-4" id="barkodEtiket">
                <h4 style="letter-spacing: 1px;"><?= e($urun['urun_adi']) ?></h4>
                <p class="text-muted mb-3">Kod: <?= e($urun['urun_kodu']) ?></p>

                <?php if (!empty($urun['barkod'])): ?>
                    <svg id="barkodSvg" style="background: #fff; padding: 12px; border-radius: 6px;"></svg>
                <?php else: ?>
                    <p class="text-muted py-4">BARKOD ATANMAMIŞ</p>
                <?php endif; ?>

                <p class="text-muted mt-3">
                    <?= number_format((float)$urun['satis_fiyati'], 2, ',', '.') ?>
                    <?= e($urun['satis_fiyati_doviz'] ?: 'TL') ?>
                </p>
            </div>
        </div>
    </div>
</div>

<style>
@media print {
    .top-navbar, .page-header, .card-header-custom, .theme-switcher { display: none !important; }
    #barkodEtiket { padding: 0 !important; }
}
</style>

<?php if (!empty($urun['barkod'])): ?>
<script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.6/dist/JsBarcode.all.min.js"></script>
<script>
    JsBarcode('#barkodSvg', <?= json_encode($urun['barkod']) ?>, {
        format: 'CODE128',
        lineColor: '#000',
        background: '#ffffff',
        width: 3,
        height: 90,
        displayValue: true,
        fontSize: 20,
        margin: 10
    });
</script>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
