<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/numara_manager.php';
require_login();

$faturalar = $pdo->query(
    'SELECT f.*, c.unvan AS cari_unvan FROM faturalar f LEFT JOIN cariler c ON c.id = f.cari_id ORDER BY f.created_at DESC'
)->fetchAll();
$makbuzlar = $pdo->query(
    'SELECT m.*, c.unvan AS cari_unvan FROM makbuzlar m LEFT JOIN cariler c ON c.id = m.cari_id ORDER BY m.created_at DESC'
)->fetchAll();
$teklifler = $pdo->query(
    'SELECT t.*, c.unvan AS cari_unvan FROM teklifler t LEFT JOIN cariler c ON c.id = t.cari_id ORDER BY t.created_at DESC'
)->fetchAll();
$servisler = $pdo->query(
    'SELECT s.*, c.unvan AS cari_unvan FROM teknik_servis s LEFT JOIN cariler c ON c.id = s.cari_id ORDER BY s.created_at DESC'
)->fetchAll();

$toplam_fatura = count($faturalar);
$toplam_makbuz = count($makbuzlar);
$toplam_teklif = count($teklifler);
$toplam_servis = count($servisler);
$toplam_evrak  = $toplam_fatura + $toplam_makbuz + $toplam_teklif + $toplam_servis;

$toplam_earsiv = 0;
foreach ($faturalar as $f) {
    if ($f['fatura_tipi'] === 'E-ARŞİV') $toplam_earsiv++;
}

$numara_bilgileri = [
    'fatura' => NumaraManager::getInfo($pdo, 'FAT'),
    'earsiv' => NumaraManager::getInfo($pdo, 'EAR'),
    'stm'    => NumaraManager::getInfo($pdo, 'STM'),
    'alm'    => NumaraManager::getInfo($pdo, 'ALM'),
    'thm'    => NumaraManager::getInfo($pdo, 'THM'),
    'odm'    => NumaraManager::getInfo($pdo, 'ODM'),
    'teklif' => NumaraManager::getInfo($pdo, 'VT'),
    'servis' => NumaraManager::getInfo($pdo, 'SRV'),
];

$page_title   = 'EVRAKLAR';
$breadcrumb   = 'Tüm Evraklar';
$current_page = 'evraklar';
$extra_css    = '<link rel="stylesheet" href="' . BASE_URL . '/assets/css/evraklar.css">';
require_once __DIR__ . '/../includes/header.php';

$sayac = 0;
?>

<div class="evrak-container">

    <!-- ÖZET KARTLARI -->
    <div class="row g-2 mb-2">
        <div class="col-md-3 col-6">
            <div class="evrak-ozet">
                <div class="ozet-sayi" style="color: #4ac8d4;"><?= $toplam_fatura ?></div>
                <div class="ozet-label">Faturalar</div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="evrak-ozet">
                <div class="ozet-sayi" style="color: #4ad46a;"><?= $toplam_earsiv ?></div>
                <div class="ozet-label">E-Arşiv</div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="evrak-ozet">
                <div class="ozet-sayi" style="color: #8ad4a0;"><?= $toplam_makbuz ?></div>
                <div class="ozet-label">Makbuzlar</div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="evrak-ozet">
                <div class="ozet-sayi" style="color: #d4c84a;"><?= $toplam_teklif ?></div>
                <div class="ozet-label">Teklifler</div>
            </div>
        </div>
    </div>

    <!-- NUMARA BİLGİ PANELİ -->
    <div class="row g-2 mb-2">
        <div class="col-md-12">
            <div class="numara-panel">
                <span class="panel-title"><i class="fas fa-hashtag"></i> SIRADAKİ NUMARALAR:</span>

                <?php
                    $numaraGosterimleri = [
                        ['id' => 'fatura-numara', 'prefix' => 'FAT', 'key' => 'fatura', 'label' => 'E-FATURA', 'cls' => 'fatura', 'varsayilan' => 'MED2026000000001'],
                        ['id' => 'earsiv-numara', 'prefix' => 'EAR', 'key' => 'earsiv', 'label' => 'E-ARŞİV', 'cls' => 'earsiv', 'varsayilan' => 'GIB2026000000001'],
                        ['id' => 'stm-numara', 'prefix' => 'STM', 'key' => 'stm', 'label' => 'SATIŞ MAK.', 'cls' => 'stm', 'varsayilan' => 'STM-2026-0001'],
                        ['id' => 'alm-numara', 'prefix' => 'ALM', 'key' => 'alm', 'label' => 'ALIŞ MAK.', 'cls' => 'alm', 'varsayilan' => 'ALM-2026-0001'],
                        ['id' => 'thm-numara', 'prefix' => 'THM', 'key' => 'thm', 'label' => 'TAHSİLAT', 'cls' => 'thm', 'varsayilan' => 'THM-2026-0001'],
                        ['id' => 'odm-numara', 'prefix' => 'ODM', 'key' => 'odm', 'label' => 'ÖDEME', 'cls' => 'odm', 'varsayilan' => 'ODM-2026-0001'],
                        ['id' => 'teklif-numara', 'prefix' => 'VT', 'key' => 'teklif', 'label' => 'TEKLİF', 'cls' => 'teklif', 'varsayilan' => 'VT-2026-0001'],
                        ['id' => 'servis-numara', 'prefix' => 'SRV', 'key' => 'servis', 'label' => 'SERVİS', 'cls' => 'servis', 'varsayilan' => 'SRV-2026-0001'],
                    ];
                ?>
                <?php foreach ($numaraGosterimleri as $ng): ?>
                <span class="numara-item">
                    <span class="label"><?= e($ng['label']) ?></span>
                    <span class="value <?= e($ng['cls']) ?>" id="<?= e($ng['id']) ?>" onclick="numaraDuzenle('<?= e($ng['id']) ?>', '<?= e($ng['prefix']) ?>')">
                        <?= e($numara_bilgileri[$ng['key']]['siradaki_format'] ?? $ng['varsayilan']) ?>
                    </span>
                    <button class="copy-btn" onclick="kopyala(document.getElementById('<?= e($ng['id']) ?>').textContent)" title="Kopyala">
                        <i class="fas fa-copy"></i>
                    </button>
                </span>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- EVRAK LİSTESİ -->
    <div class="card-custom">
        <div class="card-header-custom">
            <h5><i class="fas fa-folder-open"></i> TÜM EVRAKLAR</h5>
            <div>
                <span class="text-muted" style="font-size: 11px;">Toplam: <strong><?= $toplam_evrak ?></strong> evrak</span>
            </div>
        </div>

        <div style="padding: 10px 15px;">
            <div class="evrak-filtre">
                <div class="row g-1">
                    <div class="col-md-3">
                        <input type="text" id="evrakArama" class="form-control" placeholder="Evrak No veya Cari ara...">
                    </div>
                    <div class="col-md-2">
                        <select id="evrakTipFiltre" class="form-select">
                            <option value="TUMU">TÜM TİPLER</option>
                            <option value="FATURA">Faturalar</option>
                            <option value="MAKBUZ">Makbuzlar</option>
                            <option value="TEKLIF">Teklifler</option>
                            <option value="SERVIS">Servis</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <select id="evrakTurFiltre" class="form-select">
                            <option value="TUMU">TÜM TÜRLER</option>
                            <option value="SATIŞ">Satış</option>
                            <option value="ALIŞ">Alış</option>
                            <option value="İADE">İade</option>
                            <option value="TAHSİLAT">Tahsilat</option>
                            <option value="ÖDEME">Ödeme</option>
                            <option value="VERILEN">Verilen</option>
                            <option value="ALINAN">Alınan</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <select id="evrakDurumFiltre" class="form-select">
                            <option value="TUMU">TÜM DURUMLAR</option>
                            <option value="AKTİF">Aktif</option>
                            <option value="BEKLEMEDE">Beklemede</option>
                            <option value="TASLAK">Taslak</option>
                            <option value="İPTAL">İptal</option>
                            <option value="ONAYLANDI">Onaylandı</option>
                            <option value="OLUŞTURULDU">Oluşturuldu</option>
                            <option value="İŞLEMDE">İşlemde</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <button class="btn-primary-custom w-100" onclick="evrakFiltrele()">
                            <i class="fas fa-search"></i> FİLTRELE
                        </button>
                    </div>
                </div>
            </div>

            <div class="table-responsive">
                <table class="evrak-table" id="tumEvrakTable">
                    <thead>
                        <tr>
                            <th style="width:25px;">#</th>
                            <th style="min-width:130px;">Evrak No</th>
                            <th style="width:85px;">Tarih</th>
                            <th>Cari</th>
                            <th style="width:75px;">Tip</th>
                            <th style="width:75px;">Tür</th>
                            <th class="text-end" style="width:85px;">Tutar</th>
                            <th style="width:85px;">Durum</th>
                            <th style="width:85px;">İşlem</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($faturalar as $fatura): $sayac++; ?>
                        <tr data-tip="FATURA" data-tur="<?= e($fatura['fatura_turu']) ?>" data-durum="<?= e($fatura['durum']) ?>">
                            <td><?= $sayac ?></td>
                            <td><a href="<?= BASE_URL ?>/fatura_olustur.php?id=<?= (int)$fatura['id'] ?>" class="text-decoration-none"><strong><?= e($fatura['fatura_no']) ?></strong></a></td>
                            <td class="text-tarih"><?= $fatura['fatura_tarihi'] ? format_tarih($fatura['fatura_tarihi']) : '-' ?></td>
                            <td><?= $fatura['cari_unvan'] ? '<a href="' . BASE_URL . '/cari_detay.php?id=' . (int)$fatura['cari_id'] . '" class="text-decoration-none">' . e($fatura['cari_unvan']) . '</a>' : '-' ?></td>
                            <td><span class="badge-evrak fatura">FATURA</span></td>
                            <td><span class="badge-evrak tur-<?= mb_strtolower($fatura['fatura_turu'] ?: '', 'UTF-8') ?>"><?= e($fatura['fatura_turu'] ?: 'BELİRSİZ') ?></span></td>
                            <td class="text-end"><?= number_format((float)$fatura['genel_toplam'], 2, '.', '') ?> ₺</td>
                            <td><span class="badge-evrak durum-<?= mb_strtolower($fatura['durum'] ?: '', 'UTF-8') ?>"><?= e($fatura['durum'] ?: 'OLUŞTURULDU') ?></span></td>
                            <td>
                                <a href="<?= BASE_URL ?>/fatura_duzenle.php?id=<?= (int)$fatura['id'] ?>" class="btn-evrak-duzenle" title="Düzenle"><i class="fas fa-edit"></i></a>
                                <a href="<?= BASE_URL ?>/fatura_cikti.php?id=<?= (int)$fatura['id'] ?>" class="btn-evrak-cikti" title="Çıktı"><i class="fas fa-print"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; ?>

                        <?php foreach ($makbuzlar as $makbuz): $sayac++; ?>
                        <tr data-tip="MAKBUZ" data-tur="<?= e($makbuz['makbuz_turu']) ?>" data-durum="<?= e($makbuz['durum']) ?>">
                            <td><?= $sayac ?></td>
                            <td><a href="<?= BASE_URL ?>/makbuz_detay.php?id=<?= (int)$makbuz['id'] ?>" class="text-decoration-none"><strong><?= e($makbuz['makbuz_no']) ?></strong></a></td>
                            <td class="text-tarih"><?= $makbuz['makbuz_tarihi'] ? format_tarih($makbuz['makbuz_tarihi']) : '-' ?></td>
                            <td><?= $makbuz['cari_unvan'] ? '<a href="' . BASE_URL . '/cari_detay.php?id=' . (int)$makbuz['cari_id'] . '" class="text-decoration-none">' . e($makbuz['cari_unvan']) . '</a>' : '-' ?></td>
                            <td><span class="badge-evrak makbuz">MAKBUZ</span></td>
                            <td><span class="badge-evrak tur-<?= mb_strtolower($makbuz['makbuz_turu'] ?: '', 'UTF-8') ?>"><?= e($makbuz['makbuz_turu'] ?: 'BELİRSİZ') ?></span></td>
                            <td class="text-end"><?= number_format((float)$makbuz['genel_toplam'], 2, '.', '') ?> ₺</td>
                            <td><span class="badge-evrak durum-<?= mb_strtolower($makbuz['durum'] ?: '', 'UTF-8') ?>"><?= e($makbuz['durum'] ?: 'OLUŞTURULDU') ?></span></td>
                            <td>
                                <a href="<?= BASE_URL ?>/makbuz_detay.php?id=<?= (int)$makbuz['id'] ?>" class="btn-evrak-duzenle" title="Detay"><i class="fas fa-eye"></i></a>
                                <a href="<?= BASE_URL ?>/makbuz_cikti.php?id=<?= (int)$makbuz['id'] ?>" class="btn-evrak-cikti" title="Çıktı"><i class="fas fa-print"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; ?>

                        <?php foreach ($teklifler as $teklif): $sayac++; ?>
                        <tr data-tip="TEKLIF" data-tur="<?= e($teklif['teklif_turu']) ?>" data-durum="<?= e($teklif['durum']) ?>">
                            <td><?= $sayac ?></td>
                            <td><a href="<?= BASE_URL ?>/teklif_olustur.php?id=<?= (int)$teklif['id'] ?>" class="text-decoration-none"><strong><?= e($teklif['teklif_no']) ?></strong></a></td>
                            <td class="text-tarih"><?= $teklif['teklif_tarihi'] ? format_tarih($teklif['teklif_tarihi']) : '-' ?></td>
                            <td><?= $teklif['cari_unvan'] ? '<a href="' . BASE_URL . '/cari_detay.php?id=' . (int)$teklif['cari_id'] . '" class="text-decoration-none">' . e($teklif['cari_unvan']) . '</a>' : '-' ?></td>
                            <td><span class="badge-evrak teklif">TEKLİF</span></td>
                            <td><span class="badge-evrak tur-<?= mb_strtolower($teklif['teklif_turu'] ?: '', 'UTF-8') ?>"><?= e($teklif['teklif_turu'] ?: 'BELİRSİZ') ?></span></td>
                            <td class="text-end"><?= number_format((float)$teklif['genel_toplam'], 2, '.', '') ?> ₺</td>
                            <td><span class="badge-evrak durum-<?= mb_strtolower($teklif['durum'] ?: '', 'UTF-8') ?>"><?= e($teklif['durum'] ?: 'TASLAK') ?></span></td>
                            <td>
                                <a href="<?= BASE_URL ?>/teklif_olustur.php?id=<?= (int)$teklif['id'] ?>" class="btn-evrak-duzenle" title="Detay"><i class="fas fa-eye"></i></a>
                                <a href="<?= BASE_URL ?>/teklif_cikti.php?id=<?= (int)$teklif['id'] ?>" class="btn-evrak-cikti" title="Çıktı"><i class="fas fa-print"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; ?>

                        <?php foreach ($servisler as $servis): $sayac++; ?>
                        <tr data-tip="SERVIS" data-tur="SERVIS" data-durum="<?= e($servis['durum']) ?>">
                            <td><?= $sayac ?></td>
                            <td><a href="<?= BASE_URL ?>/teknik_servis_duzenle.php?id=<?= (int)$servis['id'] ?>" class="text-decoration-none"><strong><?= e($servis['servis_no']) ?></strong></a></td>
                            <td class="text-tarih"><?= $servis['created_at'] ? format_tarih($servis['created_at']) : '-' ?></td>
                            <td><?= $servis['cari_unvan'] ? '<a href="' . BASE_URL . '/cari_detay.php?id=' . (int)$servis['cari_id'] . '" class="text-decoration-none">' . e($servis['cari_unvan']) . '</a>' : '-' ?></td>
                            <td><span class="badge-evrak servis">SERVİS</span></td>
                            <td><span class="badge-evrak tur-servis">TEKNİK SERVİS</span></td>
                            <td class="text-end"><?= number_format((float)$servis['toplam_ucret'], 2, '.', '') ?> ₺</td>
                            <td><span class="badge-evrak durum-<?= mb_strtolower($servis['durum'] ?: '', 'UTF-8') ?>"><?= e($servis['durum'] ?: 'BEKLEMEDE') ?></span></td>
                            <td>
                                <a href="<?= BASE_URL ?>/teknik_servis_duzenle.php?id=<?= (int)$servis['id'] ?>" class="btn-evrak-duzenle" title="Düzenle"><i class="fas fa-edit"></i></a>
                                <a href="<?= BASE_URL ?>/teknik_servis_cikti.php?id=<?= (int)$servis['id'] ?>" class="btn-evrak-cikti" title="Çıktı"><i class="fas fa-print"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; ?>

                        <?php if ($sayac === 0): ?>
                        <tr>
                            <td colspan="9" class="text-center text-muted py-4">
                                <i class="fas fa-folder-open fa-3x d-block mb-3" style="color: #3a3a3a;"></i>
                                Henüz hiç evrak bulunmuyor.<br>
                                <small class="text-muted">Fatura, makbuz, teklif veya servis kaydı oluşturun.</small>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- ===== NUMARA DÜZENLEME MODAL ===== -->
<div class="modal fade" id="numaraDuzenleModal" tabindex="-1">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <h6 class="modal-title"><i class="fas fa-edit"></i> NUMARA DÜZENLE</h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="duzenlenecekAlan" value="">
                <input type="hidden" id="duzenlenecekPrefix" value="">

                <div class="mb-2">
                    <label class="form-label" style="color: #8a8a8a; font-size: 11px;">Yeni Numara</label>
                    <input type="text" id="yeniNumaraInput" class="form-control"
                           style="background: #121212; border: 1px solid #2a2a2a; color: #e0e0e0; font-size: 14px; font-weight: 700;">
                </div>
                <div class="mb-2">
                    <label class="form-label" style="color: #8a8a8a; font-size: 11px;">Sıradaki Numara (Otomatik)</label>
                    <input type="number" id="siraNumaraInput" class="form-control"
                           style="background: #121212; border: 1px solid #2a2a2a; color: #e0e0e0; font-size: 14px; font-weight: 700;"
                           placeholder="0001">
                </div>
                <small style="color: #d4c84a; font-size: 10px;">
                    <i class="fas fa-info-circle"></i>
                    "Sıradaki Numara" alanına yazacağınız değer, bundan sonraki otomatik numaraların başlangıcı olur.
                </small>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">İPTAL</button>
                <button type="button" class="btn btn-success btn-sm" onclick="numaraKaydet()">
                    <i class="fas fa-save"></i> KAYDET
                </button>
            </div>
        </div>
    </div>
</div>

<?php
$api_base_json = json_encode(BASE_URL);
$extra_js = <<<JS
<script>
var API_BASE = {$api_base_json};

function evrakFiltrele() {
    var arama = document.getElementById('evrakArama').value.toLowerCase();
    var tip = document.getElementById('evrakTipFiltre').value;
    var tur = document.getElementById('evrakTurFiltre').value;
    var durum = document.getElementById('evrakDurumFiltre').value;

    var rows = document.querySelectorAll('#tumEvrakTable tbody tr');
    rows.forEach(function(row) {
        if (row.querySelector('td[colspan]')) return;

        var goster = true;
        var text = row.textContent.toLowerCase();
        var rowTip = row.dataset.tip || '';
        var rowTur = row.dataset.tur || '';
        var rowDurum = row.dataset.durum || '';

        if (arama && !text.includes(arama)) goster = false;
        if (tip !== 'TUMU' && rowTip !== tip) goster = false;
        if (tur !== 'TUMU' && rowTur !== tur) goster = false;
        if (durum !== 'TUMU' && rowDurum !== durum) goster = false;

        row.style.display = goster ? '' : 'none';
    });
}

function numaraDuzenle(elementId, prefix) {
    var element = document.getElementById(elementId);
    if (!element) return;

    document.getElementById('duzenlenecekAlan').value = elementId;
    document.getElementById('duzenlenecekPrefix').value = prefix;
    document.getElementById('yeniNumaraInput').value = element.textContent.trim();
    document.getElementById('siraNumaraInput').value = '';

    var modal = new bootstrap.Modal(document.getElementById('numaraDuzenleModal'));
    modal.show();
}

function numaraKaydet() {
    var elementId = document.getElementById('duzenlenecekAlan').value;
    var prefix = document.getElementById('duzenlenecekPrefix').value;
    var yeniNumara = document.getElementById('yeniNumaraInput').value.trim();
    var siraNumara = document.getElementById('siraNumaraInput').value.trim();

    if (yeniNumara) {
        fetch(API_BASE + '/api/numara_guncelle.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ prefix: prefix, yeni_numara: yeniNumara, csrf_token: CSRF_TOKEN })
        })
        .then(function(response) { return response.json(); })
        .then(function(data) {
            if (data.success) {
                document.getElementById(elementId).textContent = yeniNumara;
                showToast('✅ Numara güncellendi: ' + yeniNumara, 'success');
            } else {
                showToast('❌ Hata: ' + data.message, 'error');
            }
        })
        .catch(function(error) { showToast('❌ Hata: ' + error, 'error'); });
    }

    if (siraNumara) {
        var num = parseInt(siraNumara, 10);
        if (num > 0) {
            fetch(API_BASE + '/api/numara_ayarla.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ prefix: prefix, yeni_numara: num, csrf_token: CSRF_TOKEN })
            })
            .then(function(response) { return response.json(); })
            .then(function(data) {
                if (data.success) {
                    showToast('✅ Sıradaki numara ' + num + ' olarak ayarlandı!', 'success');
                    setTimeout(function() { location.reload(); }, 1500);
                } else {
                    showToast('❌ Hata: ' + data.message, 'error');
                }
            });
        }
    }

    var modal = bootstrap.Modal.getInstance(document.getElementById('numaraDuzenleModal'));
    if (modal) modal.hide();
}

function kopyala(text) {
    navigator.clipboard.writeText(text).then(function() {
        var toast = document.createElement('div');
        toast.style.cssText = 'position: fixed; bottom: 20px; right: 20px; background: #1a3a1a; color: #8ad4a0; padding: 8px 16px; border-radius: 4px; border: 1px solid #2a5a2a; z-index: 9999; font-size: 12px;';
        toast.innerHTML = '✅ Kopyalandı: ' + text;
        document.body.appendChild(toast);
        setTimeout(function() { toast.remove(); }, 2000);
    }).catch(function() {
        alert('Kopyalandı: ' + text);
    });
}

function showToast(message, type) {
    var toast = document.createElement('div');
    var bgColor = type === 'success' ? '#1a3a1a' : '#3a1a1a';
    var textColor = type === 'success' ? '#8ad4a0' : '#d44a4a';
    var borderColor = type === 'success' ? '#2a5a2a' : '#5a2a2a';

    toast.style.cssText = 'position: fixed; bottom: 20px; right: 20px; background: ' + bgColor + '; color: ' + textColor + '; padding: 12px 20px; border-radius: 6px; border: 1px solid ' + borderColor + '; z-index: 9999; font-size: 13px; font-weight: 600; box-shadow: 0 4px 12px rgba(0,0,0,0.5); max-width: 400px;';
    toast.innerHTML = message;
    document.body.appendChild(toast);

    setTimeout(function() { toast.remove(); }, 4000);
}

document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('evrakArama').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') evrakFiltrele();
    });
    document.getElementById('evrakTipFiltre').addEventListener('change', evrakFiltrele);
    document.getElementById('evrakTurFiltre').addEventListener('change', evrakFiltrele);
    document.getElementById('evrakDurumFiltre').addEventListener('change', evrakFiltrele);
});
</script>
JS;
require_once __DIR__ . '/../includes/footer.php';
?>
