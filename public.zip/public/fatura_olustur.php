<?php
require_once __DIR__ . '/../includes/auth.php';
require_login();

$personeller = $pdo->query("SELECT * FROM cariler WHERE cari_turu = 'PERSONEL' ORDER BY unvan")->fetchAll();
$hesaplar = $pdo->query("SELECT * FROM hesaplar WHERE is_active = 1 AND hesap_turu != 'VERESİYE' ORDER BY hesap_adi")->fetchAll();

$fatura_id = safe_int($_GET['id'] ?? null, 0) ?: null;
$fatura = null;
$detaylar = [];

if ($fatura_id) {
    $stmt = $pdo->prepare('SELECT * FROM faturalar WHERE id = ?');
    $stmt->execute([$fatura_id]);
    $fatura = $stmt->fetch();
    if (!$fatura) {
        http_response_code(404);
        die('Fatura bulunamadı.');
    }
    if ($fatura['cari_id']) {
        $stmt = $pdo->prepare('SELECT * FROM cariler WHERE id = ?');
        $stmt->execute([$fatura['cari_id']]);
        $fatura['cari'] = $stmt->fetch() ?: null;
    } else {
        $fatura['cari'] = null;
    }
    $stmt = $pdo->prepare('SELECT * FROM fatura_detaylari WHERE fatura_id = ?');
    $stmt->execute([$fatura_id]);
    $detaylar = $stmt->fetchAll();
}

$cariler = $pdo->query('SELECT * FROM cariler ORDER BY unvan')->fetchAll();

$page_title   = 'SATIŞ FATURASI - E-FATURA';
$breadcrumb   = 'E-Fatura Oluştur';
$current_page = 'faturalar';
$extra_css    = '<link rel="stylesheet" href="' . BASE_URL . '/assets/css/fatura_olustur.css">';
require_once __DIR__ . '/../includes/header.php';

$now = new DateTime('now');
?>

<div class="efatura-container">
    <!-- ===== HEADER ===== -->
    <div class="efatura-header">
        <div class="satici-bilgi">
            <strong>
                <input type="text" id="satici-unvan" value="MEHMET AYDINER" style="font-weight:700; font-size:14px; width:100%;">
            </strong>
            <input type="text" id="satici-adres" value="82.Sk. Yenice Apt: No:16 07040 Kızılsaray Mh. / Muratpaşa/ Antalya" style="width:100%;">
            <div style="display:flex; gap:10px; flex-wrap:wrap;">
                <span>Tel: <input type="text" id="satici-tel" value="0 (242) 247 6699" style="width:150px;"></span>
                <span>Web: <input type="text" id="satici-web" value="http://www.medabilgisayar.net" style="width:200px;"></span>
            </div>
            <div style="display:flex; gap:10px; flex-wrap:wrap;">
                <span>E-Posta: <input type="text" id="satici-email" value="mehmetaydiner@gmail.com" style="width:200px;"></span>
                <span>Vergi Dairesi: <input type="text" id="satici-vd" value="Üçkaplar" style="width:120px;"></span>
                <span>TCKN: <input type="text" id="satici-tckn" value="39292069044" style="width:130px;"></span>
            </div>
        </div>
        <div class="fatura-bilgi">
            <div>
                <span class="etiket">Fatura No:</span>
                <input type="text" id="fatura-no" class="fatura-no-input" value="<?= e($fatura['fatura_no'] ?? 'MED2026000000039') ?>">
            </div>
            <div>
                <span class="etiket">Fatura Tarihi:</span>
                <input type="date" id="fatura-tarihi" value="<?= $now->format('Y-m-d') ?>">
            </div>
            <div>
                <span class="etiket">Fatura Tipi:</span>
                <select id="fatura-tipi">
                    <option value="SATIŞ" selected>SATIŞ</option>
                    <option value="ALIŞ">ALIŞ</option>
                    <option value="İADE">İADE</option>
                </select>
            </div>
            <div>
                <span class="etiket">Senaryo:</span>
                <select id="fatura-senaryo">
                    <option value="TİCARİ" selected>TİCARİ</option>
                    <option value="TEMEL">TEMEL</option>
                    <option value="İADE">İADE</option>
                </select>
            </div>
            <div>
                <span class="etiket">Özelleştirme:</span>
                <select id="fatura-ozellestirme">
                    <option value="TR1.2" selected>TR1.2</option>
                    <option value="TR1.1">TR1.1</option>
                </select>
            </div>
            <div>
                <span class="etiket">ETTN:</span>
                <input type="text" id="fatura-ettn" value="<?= e($fatura['gib_uuid'] ?? '462A22CE-8F58-4B60-8370-A61922D430CA') ?>" style="width:250px; background:#121212; border:1px solid #2a2a2a; border-radius:4px; padding:2px 8px; color:#e0e0e0;">
            </div>
            <div>
                <span class="etiket">Para Birimi:</span>
                <select id="fatura-para-birimi">
                    <option value="TL" selected>TL</option>
                    <option value="USD">USD</option>
                    <option value="EUR">EUR</option>
                </select>
            </div>
        </div>
    </div>

    <!-- ===== BODY ===== -->
    <div class="efatura-body">

        <!-- ALICI BİLGİLERİ -->
        <div class="alici-bilgi">
            <div class="alici-unvan">
                SAYIN <input type="text" id="alici-unvan" value="<?= e($fatura['cari']['unvan'] ?? 'FEMAC OTEL İŞLETMECİLİĞİ TURİZM İNŞAAT AŞ') ?>" style="width:100%; max-width:500px; display:inline-block;">
            </div>
            <div class="alici-detay">
                <input type="text" id="alici-adres" value="<?= e($fatura['cari']['adres'] ?? 'ŞEREFEFENDİ CAD.SELVİLİ MESCİD SOK.NO:1 KAT:1 CAĞA/ İstanbul') ?>" style="width:100%; max-width:500px;">
            </div>
            <div class="alici-detay" style="display:flex; gap:15px; flex-wrap:wrap;">
                <span>Vergi Dairesi: <input type="text" id="alici-vd" value="<?= e($fatura['cari']['vergi_dairesi'] ?? 'Hocapaşa') ?>" style="width:150px;"></span>
                <span>VKN: <input type="text" id="alici-vkn" value="<?= e($fatura['cari']['vergi_no'] ?? '3850522579') ?>" style="width:150px;"></span>
            </div>
            <div class="alici-detay" style="display:flex; gap:15px; flex-wrap:wrap;">
                <span>Tel: <input type="text" id="alici-tel" value="<?= e($fatura['cari']['telefon'] ?? '-') ?>" style="width:150px;"></span>
                <span>E-Posta: <input type="text" id="alici-email" value="<?= e($fatura['cari']['email'] ?? '-') ?>" style="width:200px;"></span>
            </div>
            <div class="mt-2">
                <select id="cari-select" class="form-select form-select-sm" style="max-width: 400px;" onchange="cariSec(this.value)">
                    <option value="">MÜŞTERİ SEÇİN...</option>
                    <?php foreach ($cariler as $cari): ?>
                    <option value="<?= (int)$cari['id'] ?>" <?= ($fatura && $fatura['cari_id'] == $cari['id']) ? 'selected' : '' ?>>
                        <?= e($cari['unvan']) ?> - <?= e($cari['vergi_no'] ?: 'VERGİ NO YOK') ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <!-- FATURA BİLGİ SATIRI -->
        <div class="fatura-bilgi-satiri">
            <div class="bilgi-item"><span class="label">ETTN:</span><span class="value" id="ettn-goster"><?= e($fatura['gib_uuid'] ?? '462A22CE-8F58-4B60-8370-A61922D430CA') ?></span></div>
            <div class="bilgi-item"><span class="label">Özelleştirme:</span><span class="value" id="ozellestirme-goster">TR1.2</span></div>
            <div class="bilgi-item"><span class="label">Senaryo:</span><span class="value" id="senaryo-goster">TİCARİ</span></div>
            <div class="bilgi-item"><span class="label">Fatura Tipi:</span><span class="value" id="fatura-tipi-goster">SATIŞ</span></div>
            <div class="bilgi-item"><span class="label">Fatura No:</span><span class="value" id="fatura-no-goster"><?= e($fatura['fatura_no'] ?? 'MED2026000000039') ?></span></div>
            <div class="bilgi-item"><span class="label">Fatura Tarihi:</span><span class="value" id="fatura-tarihi-goster"><?= $now->format('d-m-Y') ?></span></div>
        </div>

        <!-- ===== FATURA KALEMLERİ TABLOSU ===== -->
        <div class="table-responsive">
            <table class="efatura-table" id="fatura-kalemleri">
                <thead>
                    <tr>
                        <th style="width:35px;" class="text-center">SIRA</th>
                        <th style="width:18%;">MAL HİZMET</th>
                        <th style="width:8%;" class="text-center">MİKTAR</th>
                        <th style="width:12%;" class="text-end">BİRİM FİYAT</th>
                        <th style="width:8%;" class="text-center">İSKONTO %</th>
                        <th style="width:10%;" class="text-end">İSKONTO TUTARI</th>
                        <th style="width:8%;">İSKONTO NEDENİ</th>
                        <th style="width:8%;" class="text-center">KDV %</th>
                        <th style="width:10%;" class="text-end">KDV TUTARI</th>
                        <th style="width:8%;" class="text-end">DİĞER VERGİLER</th>
                        <th style="width:14%;" class="text-end">MAL HİZMET TUTARI</th>
                        <th style="width:30px;" class="text-center">İŞLEM</th>
                    </tr>
                </thead>
                <tbody id="fatura-kalem-tbody">
                    <?php if ($detaylar): ?>
                        <?php foreach ($detaylar as $i => $detay): ?>
                        <tr>
                            <td class="text-center"><?= $i + 1 ?></td>
                            <td><input type="text" class="urun-adi-input" value="<?= e($detay['urun_adi']) ?>" style="width:100%;"></td>
                            <td class="text-center"><input type="number" class="miktar-input" value="<?= number_format((float)$detay['miktar'], 0, '.', '') ?>" min="0.01" step="0.01" style="width:70px; text-align:center;" onchange="satirGuncelle(this)"></td>
                            <td class="text-end"><input type="number" class="fiyat-input" value="<?= number_format((float)$detay['birim_fiyati'], 2, '.', '') ?>" min="0" step="0.01" style="width:100px; text-align:right;" onchange="satirGuncelle(this)"></td>
                            <td class="text-center"><input type="number" class="iskonto-input" value="<?= number_format((float)$detay['iskonto'], 2, '.', '') ?>" min="0" max="100" step="0.5" style="width:60px; text-align:center;" onchange="satirGuncelle(this)"></td>
                            <td class="text-end iskonto-tutar"><?= number_format((float)$detay['iskonto_tutari'], 2, '.', '') ?></td>
                            <td><input type="text" class="iskonto-nedeni" value="İskonto -" style="width:100%;"></td>
                            <td class="text-center"><input type="number" class="kdv-input" value="<?= number_format((float)($detay['vergi_orani'] ?: 18), 0, '.', '') ?>" min="0" max="100" step="0.5" style="width:60px; text-align:center;" onchange="satirGuncelle(this)"></td>
                            <td class="text-end kdv-tutar"><?= number_format((float)($detay['vergi_tutari'] ?: 0), 2, '.', '') ?></td>
                            <td class="text-end"><input type="text" class="diger-vergiler" value="-" style="width:60px; text-align:right;"></td>
                            <td class="text-end"><strong class="satir-toplam"><?= number_format((float)$detay['toplam_tutar'], 2, '.', '') ?></strong></td>
                            <td class="text-center">
                                <button class="efatura-btn efatura-btn-danger efatura-btn-sm" onclick="satirSil(this)">
                                    <i class="fas fa-times"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr id="bos-kalem">
                            <td colspan="12" class="text-center text-muted py-3">
                                <i class="fas fa-plus-circle fa-2x d-block mb-2"></i>
                                Ürün eklemek için aşağıdaki formu kullanın
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- ===== TOPLAM BÖLÜMÜ ===== -->
        <div class="toplam-bolumu">
            <div class="toplam-kutusu">
                <div class="total-row">
                    <span class="label">MAL HİZMET TOPLAMI</span>
                    <span class="value" id="ara-toplam"><?= number_format((float)($fatura['ara_toplam'] ?? 0), 2, '.', '') ?></span>
                </div>
                <div class="total-row">
                    <span class="label">İSKONTO TUTARI</span>
                    <span class="value" id="iskonto-tutari"><?= number_format((float)($fatura['iskonto_tutari'] ?? 0), 2, '.', '') ?></span>
                </div>
                <div class="total-row">
                    <span class="label">KDV TUTARI</span>
                    <span class="value" id="vergi-tutari"><?= number_format((float)($fatura['vergi_tutari'] ?? 0), 2, '.', '') ?></span>
                </div>
                <div class="total-row genel-toplam">
                    <span class="label">GENEL TOPLAM</span>
                    <span class="value" id="genel-toplam"><?= number_format((float)($fatura['genel_toplam'] ?? 0), 2, '.', '') ?></span>
                </div>
            </div>
        </div>

        <!-- ===== ÖDEME DAĞILIMI ===== -->
        <div class="no-print" style="margin-top: 15px; background: #121212; border: 1px solid #2a2a2a; border-radius: 6px; padding: 12px 15px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                <div style="font-size: 11px; font-weight: 700; color: #8a8a8a; text-transform: uppercase; letter-spacing: 0.5px;">
                    <i class="fas fa-money-bill-wave"></i> ÖDEME DAĞILIMI
                </div>
                <button type="button" class="btn btn-outline-success btn-sm" onclick="odemeSatiriEkle()">
                    <i class="fas fa-plus"></i> ÖDEME EKLE
                </button>
            </div>
            <div id="odemeSatirlari"></div>
            <div class="d-flex justify-content-end gap-4 mt-2" style="font-size: 12px;">
                <span>Genel Toplam: <strong id="odemeGenelToplamGoster">0.00</strong></span>
                <span>Ödenen: <strong id="odemeOdenenGoster" class="text-success">0.00</strong></span>
                <span>Kalan: <strong id="odemeKalanGoster">0.00</strong></span>
            </div>
            <small class="text-muted d-block mt-1">
                Ödemeyi birden fazla kanaldan (nakit + havale + kredi kartı gibi) bölebilirsin.
                Kalan tutar veresiye/borç olarak izlenir.
            </small>
        </div>

        <!-- ===== ÜRÜN EKLEME FORMU ===== -->
        <div class="urun-ekle-formu no-print" style="margin-top: 15px; background: #121212; border: 1px solid #2a2a2a; border-radius: 6px; padding: 12px 15px;">
            <div style="font-size: 11px; font-weight: 700; color: #8a8a8a; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 8px;">
                <i class="fas fa-plus-circle"></i> ÜRÜN EKLE
            </div>

            <div class="row g-2 align-items-end">
                <div class="col-md-3">
                    <label class="form-label" style="font-size: 10px; margin-bottom: 2px;">ÜRÜN ARA</label>
                    <input type="text" id="urun-ara" class="form-control form-control-sm" placeholder="Ürün adı veya barkod ara...">
                </div>
                <div class="col-md-1">
                    <label class="form-label" style="font-size: 10px; margin-bottom: 2px;">&nbsp;</label>
                    <button class="efatura-btn efatura-btn-primary w-100" onclick="urunAra()" style="font-size: 11px; padding: 5px 10px; height: 31px;">
                        <i class="fas fa-search"></i> ARA
                    </button>
                </div>
                <div class="col-md-4">
                    <label class="form-label" style="font-size: 10px; margin-bottom: 2px;">ÜRÜN SEÇ</label>
                    <select id="urun-listesi" class="form-select form-select-sm">
                        <option value="">Ürün seçin...</option>
                    </select>
                </div>
                <div class="col-md-4" style="display: flex; gap: 6px; align-items: flex-end;">
                    <div style="flex: 1;">
                        <label class="form-label" style="font-size: 10px; margin-bottom: 2px;">MİKTAR</label>
                        <input type="number" id="urun-miktar" class="form-control form-control-sm" value="1" min="0.01" step="0.01" style="height: 31px;">
                    </div>
                    <div style="flex: 1;">
                        <label class="form-label" style="font-size: 10px; margin-bottom: 2px;">FİYAT</label>
                        <input type="number" id="urun-fiyat" class="form-control form-control-sm" step="0.01" value="0" style="height: 31px;">
                    </div>
                    <div style="flex: 1;">
                        <label class="form-label" style="font-size: 10px; margin-bottom: 2px;">İSKONTO %</label>
                        <input type="number" id="urun-iskonto" class="form-control form-control-sm" value="0" min="0" max="100" step="1" style="height: 31px;">
                    </div>
                    <div style="flex: 1;">
                        <label class="form-label" style="font-size: 10px; margin-bottom: 2px;">KDV %</label>
                        <input type="number" id="urun-kdv" class="form-control form-control-sm" value="20" min="0" max="100" step="1" style="height: 31px;">
                    </div>
                    <div>
                        <label class="form-label" style="font-size: 10px; margin-bottom: 2px;">&nbsp;</label>
                        <button class="efatura-btn efatura-btn-success" onclick="kalemEkle()" style="font-size: 11px; padding: 5px 12px; height: 31px; white-space: nowrap;">
                            <i class="fas fa-plus"></i> EKLE
                        </button>
                    </div>
                </div>
            </div>

            <div class="mt-3 pt-2" style="border-top: 1px solid #2a2a2a;">
                <button type="button" class="efatura-btn efatura-btn-warning" data-bs-toggle="modal" data-bs-target="#yeniUrunModal" style="font-size: 12px; padding: 6px 16px; width: 100%;">
                    <i class="fas fa-plus-circle"></i> YENİ ÜRÜN EKLE
                </button>
                <div style="font-size: 10px; color: #6a6a6a; text-align: center; margin-top: 4px;">
                    Listede olmayan ürünleri eklemek için tıklayın
                </div>
            </div>
        </div>

        <!-- ===== NOTLAR VE İŞLEMLER ===== -->
        <div class="row g-3 mt-2">
            <div class="col-md-6">
                <div style="background: #121212; border: 1px solid #2a2a2a; border-radius: 6px; padding: 10px 15px;">
                    <div style="font-size: 11px; font-weight: 700; color: #8a8a8a; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px;">FATURA NOTU</div>
                    <textarea id="fatura-notu" class="form-control form-control-sm" rows="2" placeholder="Fatura notu..."><?= e($fatura['aciklama'] ?? '') ?></textarea>
                </div>
            </div>
            <div class="col-md-6 no-print">
                <div style="background: #121212; border: 1px solid #2a2a2a; border-radius: 6px; padding: 10px 15px;">
                    <div style="font-size: 11px; font-weight: 700; color: #8a8a8a; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px;">İŞLEMLER</div>
                    <div class="d-flex flex-wrap gap-2">
                        <button class="efatura-btn efatura-btn-success" onclick="faturaKaydet()" style="font-size: 11px; padding: 5px 12px;">
                            <i class="fas fa-save"></i> KAYDET
                        </button>
                        <button class="efatura-btn efatura-btn-primary" onclick="window.print()" style="font-size: 11px; padding: 5px 12px;">
                            <i class="fas fa-print"></i> YAZDIR
                        </button>
                        <?php if ($fatura): ?>
                        <a class="efatura-btn efatura-btn-warning" href="<?= BASE_URL ?>/fatura_xml_olustur.php?id=<?= (int)$fatura['id'] ?>" target="_blank" style="font-size: 11px; padding: 5px 12px;">
                            <i class="fas fa-file-code"></i> XML
                        </a>
                        <?php endif; ?>
                        <button class="efatura-btn efatura-btn-danger" onclick="faturaIptal()" style="font-size: 11px; padding: 5px 12px;">
                            <i class="fas fa-times"></i> İPTAL
                        </button>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- ===== YENİ ÜRÜN EKLE MODAL ===== -->
<div class="modal fade" id="yeniUrunModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-box"></i> YENİ ÜRÜN EKLE</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="yeniUrunForm" onsubmit="return false;">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">ÜRÜN KODU <span class="text-danger">*</span></label>
                            <input type="text" id="modal_urun_kodu" class="form-control" placeholder="PR-001" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">ÜRÜN ADI <span class="text-danger">*</span></label>
                            <input type="text" id="modal_urun_adi" class="form-control" placeholder="LAPTOP" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">BARKOD</label>
                            <div class="input-group">
                                <input type="text" id="modal_barkod" class="form-control" placeholder="OTOMATİK">
                                <button type="button" class="btn btn-outline-primary" onclick="modalBarkodOlustur()">
                                    <i class="fas fa-qrcode"></i> OLUŞTUR
                                </button>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">SERİ NUMARASI</label>
                            <input type="text" id="modal_seri_no" class="form-control" placeholder="SN-2024-001">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">KATEGORİ</label>
                            <input type="text" id="modal_kategori" class="form-control" placeholder="BİLGİSAYAR">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">BİRİM</label>
                            <select id="modal_birim" class="form-select">
                                <option value="ADET">ADET</option>
                                <option value="KG">KG</option>
                                <option value="METRE">METRE</option>
                                <option value="LİTRE">LİTRE</option>
                                <option value="SAAT">SAAT</option>
                                <option value="PAKET">PAKET</option>
                                <option value="KUTU">KUTU</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">ÜRÜN TİPİ</label>
                            <select id="modal_urun_tipi" class="form-select">
                                <option value="SIFIR">SIFIR</option>
                                <option value="2.EL">2.EL</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">ALIŞ FİYATI</label>
                            <div class="input-group">
                                <input type="number" id="modal_alis_fiyati" class="form-control" step="0.01" value="0">
                                <select id="modal_alis_doviz" class="form-select" style="max-width: 80px;">
                                    <option value="TL">TL</option>
                                    <option value="USD">USD</option>
                                    <option value="EUR">EUR</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">SATIŞ FİYATI</label>
                            <div class="input-group">
                                <input type="number" id="modal_satis_fiyati" class="form-control" step="0.01" value="0">
                                <select id="modal_satis_doviz" class="form-select" style="max-width: 80px;">
                                    <option value="TL">TL</option>
                                    <option value="USD">USD</option>
                                    <option value="EUR">EUR</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">STOK MİKTARI</label>
                            <input type="number" id="modal_stok_miktari" class="form-control" step="0.01" value="0">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">MIN. STOK</label>
                            <input type="number" id="modal_min_stok" class="form-control" step="0.01" value="0">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">MAX. STOK</label>
                            <input type="number" id="modal_max_stok" class="form-control" step="0.01" value="0">
                        </div>
                        <div class="col-md-12">
                            <label class="form-label">AÇIKLAMA</label>
                            <textarea id="modal_aciklama" class="form-control" rows="2" placeholder="ÜRÜN AÇIKLAMASI..."></textarea>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="efatura-btn efatura-btn-secondary" data-bs-dismiss="modal">İPTAL</button>
                <button type="button" class="efatura-btn efatura-btn-success" onclick="modalUrunKaydet()">
                    <i class="fas fa-save"></i> KAYDET VE EKLE
                </button>
            </div>
        </div>
    </div>
</div>

<!-- ===== PRİM POPUP ===== -->
<div class="modal fade" id="primModal" tabindex="-1" data-bs-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-hand-holding-usd"></i> PRİM İŞLEMİ</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div id="primSoruAlani" class="text-center py-3">
                    <p style="font-size: 15px;">Bu satış için <strong>prim işlemi</strong> yapılacak mı?</p>
                    <p class="text-muted" style="font-size: 12px;">Satış tutarı: <strong id="primSatisTutariGoster">-</strong></p>
                    <div class="d-flex gap-2 justify-content-center mt-3">
                        <button type="button" class="btn btn-success" onclick="primEvet()">
                            <i class="fas fa-check"></i> EVET
                        </button>
                        <button type="button" class="btn btn-secondary" onclick="primHayirYonlendir()">
                            <i class="fas fa-times"></i> HAYIR
                        </button>
                    </div>
                </div>

                <div id="primDetayAlani" style="display: none;">
                    <div class="mb-3">
                        <label class="form-label">Prim Verilecek Kişi <span class="text-danger">*</span></label>
                        <select id="primKisi" class="form-select">
                            <option value="">-- Seçin --</option>
                            <?php foreach ($personeller as $p): ?>
                                <option value="<?= (int)$p['id'] ?>"><?= e($p['unvan']) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <?php if (!$personeller): ?>
                            <small class="text-warning">
                                Henüz PERSONEL türünde bir cari yok.
                                <a href="<?= BASE_URL ?>/cari_ekle.php" target="_blank">Buradan ekleyebilirsiniz</a>.
                            </small>
                        <?php endif; ?>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Hesaplama Yöntemi</label>
                        <div class="d-flex gap-3">
                            <label class="d-flex align-items-center gap-1">
                                <input type="radio" name="primYontem" value="SABIT" checked onchange="primYontemDegisti()"> Sabit Tutar
                            </label>
                            <label class="d-flex align-items-center gap-1">
                                <input type="radio" name="primYontem" value="ORAN" onchange="primYontemDegisti()"> Satıştan Oranla
                            </label>
                        </div>
                    </div>
                    <div id="primSabitAlani" class="mb-3">
                        <label class="form-label">Prim Tutarı (₺)</label>
                        <input type="number" id="primTutarSabit" class="form-control" step="0.01" min="0" value="0">
                    </div>
                    <div id="primOranAlani" class="mb-3" style="display: none;">
                        <label class="form-label">Oran (%)</label>
                        <input type="number" id="primOranYuzde" class="form-control" step="0.1" min="0" max="100" value="0" oninput="primOranHesapla()">
                        <small class="text-muted">Hesaplanan tutar: <strong id="primHesaplananTutar">0.00</strong> ₺</small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Açıklama (opsiyonel)</label>
                        <input type="text" id="primAciklama" class="form-control">
                    </div>
                </div>
            </div>
            <div class="modal-footer" id="primModalFooter" style="display: none;">
                <button type="button" class="btn btn-secondary btn-sm" onclick="primHayirYonlendir()">İPTAL</button>
                <button type="button" class="btn btn-success btn-sm" onclick="primKaydet()">
                    <i class="fas fa-save"></i> KAYDET
                </button>
            </div>
        </div>
    </div>
</div>

<?php
$api_base_json = json_encode(BASE_URL);
$fatura_id_js = (int)($fatura['id'] ?? 0);
$odeme_hesaplari_json = json_encode(array_map(fn($h) => ['id' => (int)$h['id'], 'ad' => $h['hesap_adi']], $hesaplar));
$odeme_kanallari_json = json_encode(['NAKİT', 'KREDİ KARTI', 'BANKA HAVALESİ', 'EFT', 'ÇEK', 'SENET', 'VERESİYE']);
$extra_js = <<<JS
<script>
var API_BASE = {$api_base_json};
var FATURA_ID = {$fatura_id_js};
var ODEME_HESAPLARI = {$odeme_hesaplari_json};
var ODEME_KANALLARI = {$odeme_kanallari_json};
var odemeSatirSayaci = 0;
var primSatisTutari = 0;
var primReferansNo = '';

// ========== CARİ SEÇ ==========
function cariSec(id) {
    if (!id) return;
    fetch(API_BASE + '/api/cari_detay.php?id=' + id)
        .then(function(response) { return response.json(); })
        .then(function(data) {
            document.getElementById('alici-unvan').value = data.unvan || '';
            document.getElementById('alici-adres').value = data.adres || '';
            document.getElementById('alici-vd').value = data.vergi_dairesi || '';
            document.getElementById('alici-vkn').value = data.vergi_no || '';
            document.getElementById('alici-tel').value = data.telefon || '';
            document.getElementById('alici-email').value = data.email || '';
        });
}

// ========== ÜRÜN ARA ==========
function urunAra() {
    var q = document.getElementById('urun-ara').value.trim();
    if (q.length < 2) return;

    fetch(API_BASE + '/api/stok_ara.php?q=' + encodeURIComponent(q))
        .then(function(response) { return response.json(); })
        .then(function(data) {
            var select = document.getElementById('urun-listesi');
            select.innerHTML = '<option value="">Ürün seçin...</option>';
            data.forEach(function(urun) {
                select.innerHTML += '<option value="' + urun.id + '" data-fiyat="' + urun.satis_fiyati + '" data-ad="' + urun.urun_adi + '" data-barkod="' + (urun.barkod || '') + '">' + urun.urun_adi + ' - ' + (urun.barkod || 'BARKOD YOK') + ' (' + urun.satis_fiyati + ' ' + (urun.satis_fiyati_doviz || 'TL') + ')</option>';
            });
        });
}

// ========== KALEM EKLE ==========
function kalemEkle() {
    var select = document.getElementById('urun-listesi');
    var selected = select.options[select.selectedIndex];
    if (!selected.value) {
        alert('Lütfen bir ürün seçin!');
        return;
    }

    var miktar = parseFloat(document.getElementById('urun-miktar').value) || 1;
    var fiyat = parseFloat(document.getElementById('urun-fiyat').value) || 0;
    var iskonto = parseFloat(document.getElementById('urun-iskonto').value) || 0;
    var kdvOran = parseFloat(document.getElementById('urun-kdv').value) || 18;

    var satirToplam = miktar * fiyat;
    var iskontoTutar = satirToplam * (iskonto / 100);
    var iskontoSonrasi = satirToplam - iskontoTutar;
    var kdvTutar = iskontoSonrasi * (kdvOran / 100);
    var genelSatirToplam = iskontoSonrasi + kdvTutar;

    var tbody = document.getElementById('fatura-kalem-tbody');
    var bos = document.getElementById('bos-kalem');
    if (bos) bos.remove();

    var index = tbody.children.length + 1;
    var row = document.createElement('tr');
    row.innerHTML =
        '<td class="text-center">' + index + '</td>' +
        '<td><input type="text" class="urun-adi-input" value="' + selected.dataset.ad + '" style="width:100%;"></td>' +
        '<td class="text-center"><input type="number" class="miktar-input" value="' + miktar.toFixed(2) + '" min="0.01" step="0.01" style="width:70px; text-align:center;" onchange="satirGuncelle(this)"></td>' +
        '<td class="text-end"><input type="number" class="fiyat-input" value="' + fiyat.toFixed(2) + '" min="0" step="0.01" style="width:100px; text-align:right;" onchange="satirGuncelle(this)"></td>' +
        '<td class="text-center"><input type="number" class="iskonto-input" value="' + iskonto.toFixed(0) + '" min="0" max="100" step="0.5" style="width:60px; text-align:center;" onchange="satirGuncelle(this)"></td>' +
        '<td class="text-end iskonto-tutar">' + iskontoTutar.toFixed(2) + '</td>' +
        '<td><input type="text" class="iskonto-nedeni" value="İskonto -" style="width:100%;"></td>' +
        '<td class="text-center"><input type="number" class="kdv-input" value="' + kdvOran + '" min="0" max="100" step="0.5" style="width:60px; text-align:center;" onchange="satirGuncelle(this)"></td>' +
        '<td class="text-end kdv-tutar">' + kdvTutar.toFixed(2) + '</td>' +
        '<td class="text-end"><input type="text" class="diger-vergiler" value="-" style="width:60px; text-align:right;"></td>' +
        '<td class="text-end"><strong class="satir-toplam">' + genelSatirToplam.toFixed(2) + '</strong></td>' +
        '<td class="text-center"><button class="efatura-btn efatura-btn-danger efatura-btn-sm" onclick="satirSil(this)"><i class="fas fa-times"></i></button></td>';
    tbody.appendChild(row);
    hesaplaToplam();
}

// ========== SATIR SİL ==========
function satirSil(btn) {
    var row = btn.closest('tr');
    row.remove();
    document.querySelectorAll('#fatura-kalem-tbody tr').forEach(function(tr, i) {
        tr.cells[0].textContent = i + 1;
    });
    hesaplaToplam();
}

// ========== SATIR GÜNCELLE ==========
function satirGuncelle(input) {
    var row = input.closest('tr');
    if (!row || row.id === 'bos-kalem') return;

    var miktar = parseFloat(row.querySelector('.miktar-input').value) || 0;
    var fiyat = parseFloat(row.querySelector('.fiyat-input').value) || 0;
    var iskonto = parseFloat(row.querySelector('.iskonto-input').value) || 0;
    var kdvOran = parseFloat(row.querySelector('.kdv-input').value) || 0;

    var satirToplam = miktar * fiyat;
    var iskontoTutar = satirToplam * (iskonto / 100);
    var iskontoSonrasi = satirToplam - iskontoTutar;
    var kdvTutar = iskontoSonrasi * (kdvOran / 100);
    var genelSatirToplam = iskontoSonrasi + kdvTutar;

    row.querySelector('.iskonto-tutar').textContent = iskontoTutar.toFixed(2);
    row.querySelector('.kdv-tutar').textContent = kdvTutar.toFixed(2);
    row.querySelector('.satir-toplam').textContent = genelSatirToplam.toFixed(2);

    hesaplaToplam();
}

// ========== TOPLAM HESAPLA ==========
function hesaplaToplam() {
    var araToplam = 0;
    var toplamIskonto = 0;
    var toplamKdv = 0;
    var rows = document.querySelectorAll('#fatura-kalem-tbody tr');

    rows.forEach(function(row) {
        if (row.id === 'bos-kalem') return;
        var toplamText = row.querySelector('.satir-toplam').textContent.trim();
        araToplam += parseFloat(toplamText) || 0;

        var iskontoText = row.querySelector('.iskonto-tutar').textContent.trim();
        toplamIskonto += parseFloat(iskontoText) || 0;

        var kdvText = row.querySelector('.kdv-tutar').textContent.trim();
        toplamKdv += parseFloat(kdvText) || 0;
    });

    document.getElementById('ara-toplam').textContent = araToplam.toFixed(2);
    document.getElementById('iskonto-tutari').textContent = toplamIskonto.toFixed(2);
    document.getElementById('vergi-tutari').textContent = toplamKdv.toFixed(2);
    document.getElementById('genel-toplam').textContent = araToplam.toFixed(2);
    odemeOzetGuncelle();
}

// ============================================================
// ÖDEME DAĞILIMI (çoklu kanal/kasa ile bölünmüş ödeme)
// ============================================================
function odemeTuruDegisti(selectEl) {
    var satir = selectEl.closest('.odeme-satiri');
    if (!satir) return;
    var hesapSelect = satir.querySelector('.odeme-hesap-select');
    if (!hesapSelect) return;

    if (selectEl.value === 'VERESİYE') {
        hesapSelect.value = '';
        hesapSelect.disabled = true;
    } else {
        hesapSelect.disabled = false;
    }
}

function odemeSatiriEkle() {
    odemeSatirSayaci++;
    var satirId = odemeSatirSayaci;

    var kanalOptions = ODEME_KANALLARI.map(function(k) {
        return '<option value="' + k + '"' + (k === 'NAKİT' ? ' selected' : '') + '>' + k + '</option>';
    }).join('');

    var hesapOptions = '<option value="">-- Kasa Seçin --</option>' + ODEME_HESAPLARI.map(function(h) {
        return '<option value="' + h.id + '">' + h.ad + '</option>';
    }).join('');

    var satir = document.createElement('div');
    satir.className = 'row g-1 mb-1 odeme-satiri';
    satir.dataset.satirId = satirId;
    satir.innerHTML =
        '<div class="col-4"><select class="form-select form-select-sm odeme-turu-select" onchange="odemeTuruDegisti(this)">' + kanalOptions + '</select></div>' +
        '<div class="col-4"><select class="form-select form-select-sm odeme-hesap-select">' + hesapOptions + '</select></div>' +
        '<div class="col-3"><input type="number" class="form-control form-control-sm odeme-tutar-input" step="0.01" min="0" value="0" oninput="odemeOzetGuncelle()"></div>' +
        '<div class="col-1"><button type="button" class="btn btn-outline-danger btn-sm" onclick="odemeSatiriSil(' + satirId + ')"><i class="fas fa-times"></i></button></div>';

    document.getElementById('odemeSatirlari').appendChild(satir);
    odemeOzetGuncelle();
}

function odemeSatiriSil(satirId) {
    var satir = document.querySelector('.odeme-satiri[data-satir-id="' + satirId + '"]');
    if (satir) satir.remove();
    odemeOzetGuncelle();
}

function odemeOzetGuncelle() {
    var genelToplamEl = document.getElementById('genel-toplam');
    var genelToplam = genelToplamEl ? (parseFloat(genelToplamEl.textContent) || 0) : 0;
    var odenenToplam = 0;

    document.querySelectorAll('.odeme-tutar-input').forEach(function(input) {
        odenenToplam += parseFloat(input.value) || 0;
    });

    var kalan = genelToplam - odenenToplam;

    document.getElementById('odemeGenelToplamGoster').textContent = genelToplam.toFixed(2);
    document.getElementById('odemeOdenenGoster').textContent = odenenToplam.toFixed(2);

    var kalanEl = document.getElementById('odemeKalanGoster');
    kalanEl.textContent = kalan.toFixed(2);
    kalanEl.className = kalan > 0.01 ? 'text-warning' : (kalan < -0.01 ? 'text-danger' : 'text-success');
}

// ========== MODAL BARKOD OLUŞTUR ==========
function modalBarkodOlustur() {
    var prefix = '869';
    var random = '';
    for (var i = 0; i < 9; i++) random += Math.floor(Math.random() * 10);
    var check = Math.floor(Math.random() * 10);
    document.getElementById('modal_barkod').value = prefix + random + check;
}

// ========== MODAL ÜRÜN KAYDET ==========
function modalUrunKaydet() {
    var urun_kodu = document.getElementById('modal_urun_kodu').value.trim().toUpperCase();
    var urun_adi = document.getElementById('modal_urun_adi').value.trim().toUpperCase();
    if (!urun_kodu) { alert('Ürün kodu zorunludur!'); return; }
    if (!urun_adi) { alert('Ürün adı zorunludur!'); return; }

    var satis_fiyati = parseFloat(document.getElementById('modal_satis_fiyati').value) || 0;
    var satis_doviz = document.getElementById('modal_satis_doviz').value;
    var barkod = document.getElementById('modal_barkod').value.trim();

    var formData = new FormData();
    formData.append('csrf_token', CSRF_TOKEN);
    formData.append('urun_kodu', urun_kodu);
    formData.append('urun_adi', urun_adi);
    formData.append('barkod', barkod);
    formData.append('seri_no', document.getElementById('modal_seri_no').value.trim().toUpperCase());
    formData.append('kategori', document.getElementById('modal_kategori').value.trim().toUpperCase());
    formData.append('birim', document.getElementById('modal_birim').value);
    formData.append('urun_tipi', document.getElementById('modal_urun_tipi').value);
    formData.append('alis_fiyati', document.getElementById('modal_alis_fiyati').value);
    formData.append('alis_fiyati_doviz', document.getElementById('modal_alis_doviz').value);
    formData.append('satis_fiyati', satis_fiyati);
    formData.append('satis_fiyati_doviz', satis_doviz);
    formData.append('stok_miktari', document.getElementById('modal_stok_miktari').value);
    formData.append('min_stok', document.getElementById('modal_min_stok').value);
    formData.append('max_stok', document.getElementById('modal_max_stok').value);
    formData.append('aciklama', document.getElementById('modal_aciklama').value.trim().toUpperCase());

    fetch(API_BASE + '/api/stok_ekle_ajax.php', { method: 'POST', body: formData })
        .then(function(response) { return response.json(); })
        .then(function(data) {
            if (data.success) {
                var select = document.getElementById('urun-listesi');
                var option = document.createElement('option');
                option.value = data.urun_id;
                option.dataset.fiyat = satis_fiyati;
                option.dataset.ad = urun_adi;
                option.dataset.barkod = barkod || '';
                option.text = urun_adi + ' - ' + (barkod || 'BARKOD YOK') + ' (' + satis_fiyati + ' ' + satis_doviz + ')';
                select.appendChild(option);
                select.value = data.urun_id;
                document.getElementById('urun-fiyat').value = satis_fiyati;

                bootstrap.Modal.getInstance(document.getElementById('yeniUrunModal')).hide();
                alert('Ürün başarıyla eklendi! Şimdi faturaya ekleyebilirsiniz.');
            } else {
                alert('Hata: ' + (data.message || 'Ürün eklenemedi!'));
            }
        })
        .catch(function(error) { alert('Hata oluştu: ' + error); });
}

document.getElementById('yeniUrunModal').addEventListener('hidden.bs.modal', function() {
    ['modal_urun_kodu','modal_urun_adi','modal_barkod','modal_seri_no','modal_kategori','modal_aciklama'].forEach(function(id) {
        document.getElementById(id).value = '';
    });
    ['modal_stok_miktari','modal_min_stok','modal_max_stok','modal_alis_fiyati','modal_satis_fiyati'].forEach(function(id) {
        document.getElementById(id).value = '0';
    });
});

// ========== FATURA KAYDET ==========
function faturaKaydet() {
    var rows = document.querySelectorAll('#fatura-kalem-tbody tr');
    if (rows.length === 0 || (rows.length === 1 && rows[0].id === 'bos-kalem')) {
        alert('Lütfen en az bir ürün ekleyin!');
        return false;
    }

    var formData = new FormData();
    formData.append('csrf_token', CSRF_TOKEN);
    if (FATURA_ID) formData.append('fatura_id', FATURA_ID);
    formData.append('fatura_no', document.getElementById('fatura-no').value);
    formData.append('fatura_tarihi', document.getElementById('fatura-tarihi').value);
    formData.append('fatura_tipi', document.getElementById('fatura-tipi').value);
    formData.append('fatura_senaryo', document.getElementById('fatura-senaryo').value);
    formData.append('fatura_ozellestirme', document.getElementById('fatura-ozellestirme').value);
    formData.append('fatura_ettn', document.getElementById('fatura-ettn').value);
    formData.append('para_birimi', document.getElementById('fatura-para-birimi').value);
    formData.append('aciklama', document.getElementById('fatura-notu').value);

    formData.append('alici_unvan', document.getElementById('alici-unvan').value);
    formData.append('alici_adres', document.getElementById('alici-adres').value);
    formData.append('alici_vd', document.getElementById('alici-vd').value);
    formData.append('alici_vkn', document.getElementById('alici-vkn').value);
    formData.append('alici_tel', document.getElementById('alici-tel').value);
    formData.append('alici_email', document.getElementById('alici-email').value);

    document.querySelectorAll('#fatura-kalem-tbody tr').forEach(function(row) {
        if (row.id === 'bos-kalem') return;
        formData.append('urun_adi[]', row.querySelector('.urun-adi-input').value);
        formData.append('miktar[]', row.querySelector('.miktar-input').value);
        formData.append('fiyat[]', row.querySelector('.fiyat-input').value);
        formData.append('iskonto[]', row.querySelector('.iskonto-input').value);
        formData.append('iskonto_nedeni[]', row.querySelector('.iskonto-nedeni').value);
        formData.append('kdv[]', row.querySelector('.kdv-input').value);
        formData.append('diger_vergiler[]', row.querySelector('.diger-vergiler').value);
    });

    document.querySelectorAll('.odeme-satiri').forEach(function(satir) {
        var tutar = parseFloat(satir.querySelector('.odeme-tutar-input').value) || 0;
        if (tutar <= 0) return;
        formData.append('odeme_turu[]', satir.querySelector('.odeme-turu-select').value);
        formData.append('odeme_hesap_id[]', satir.querySelector('.odeme-hesap-select').value);
        formData.append('odeme_tutar[]', tutar);
    });

    fetch(API_BASE + '/fatura_kaydet.php', { method: 'POST', body: formData })
        .then(function(response) { return response.json(); })
        .then(function(data) {
            if (data.success) {
                var faturaTipi = document.getElementById('fatura-tipi').value;
                if (faturaTipi === 'SATIŞ') {
                    primPopupGoster();
                } else {
                    alert('Fatura başarıyla kaydedildi!');
                    window.location.href = API_BASE + '/faturalar.php';
                }
            } else {
                alert('Hata: ' + (data.message || 'Fatura kaydedilemedi!'));
            }
        })
        .catch(function(error) { alert('Hata oluştu: ' + error); });
}

// ============================================================
// PRİM POPUP
// ============================================================
function primPopupGoster() {
    var tutarText = document.getElementById('genel-toplam').textContent.replace(/\./g, '').replace(',', '.');
    primSatisTutari = parseFloat(tutarText) || 0;
    primReferansNo = document.getElementById('fatura-no').value;

    document.getElementById('primSatisTutariGoster').textContent = primSatisTutari.toFixed(2) + ' ₺ (' + primReferansNo + ')';
    document.getElementById('primSoruAlani').style.display = 'block';
    document.getElementById('primDetayAlani').style.display = 'none';
    document.getElementById('primModalFooter').style.display = 'none';

    var modal = new bootstrap.Modal(document.getElementById('primModal'));
    modal.show();
}

function primHayirYonlendir() {
    var modal = bootstrap.Modal.getInstance(document.getElementById('primModal'));
    if (modal) modal.hide();
    window.location.href = API_BASE + '/faturalar.php';
}

function primEvet() {
    document.getElementById('primSoruAlani').style.display = 'none';
    document.getElementById('primDetayAlani').style.display = 'block';
    document.getElementById('primModalFooter').style.display = 'flex';
}

function primYontemDegisti() {
    var yontem = document.querySelector('input[name="primYontem"]:checked').value;
    document.getElementById('primSabitAlani').style.display = yontem === 'SABIT' ? 'block' : 'none';
    document.getElementById('primOranAlani').style.display = yontem === 'ORAN' ? 'block' : 'none';
    if (yontem === 'ORAN') primOranHesapla();
}

function primOranHesapla() {
    var oran = parseFloat(document.getElementById('primOranYuzde').value) || 0;
    document.getElementById('primHesaplananTutar').textContent = (primSatisTutari * oran / 100).toFixed(2);
}

function primKaydet() {
    var kisiId = document.getElementById('primKisi').value;
    if (!kisiId) { alert('Lütfen prim verilecek kişiyi seçin!'); return; }

    var yontem = document.querySelector('input[name="primYontem"]:checked').value;
    var tutar, oran;
    if (yontem === 'SABIT') {
        tutar = parseFloat(document.getElementById('primTutarSabit').value) || 0;
        oran = null;
    } else {
        oran = parseFloat(document.getElementById('primOranYuzde').value) || 0;
        tutar = primSatisTutari * oran / 100;
    }
    if (tutar <= 0) { alert('Geçerli bir prim tutarı girin!'); return; }

    fetch(API_BASE + '/api/prim_ekle.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            cari_id: kisiId, tutar: tutar, oran: oran, matrah: primSatisTutari,
            referans_no: primReferansNo, fatura_id: {$fatura_id_js} || null,
            aciklama: document.getElementById('primAciklama').value, csrf_token: CSRF_TOKEN,
        }),
    })
        .then(function(r) { return r.json(); })
        .then(function(data) {
            if (!data.success) alert('Prim kaydedilemedi: ' + data.message);
            window.location.href = API_BASE + '/faturalar.php';
        })
        .catch(function() { window.location.href = API_BASE + '/faturalar.php'; });
}

function faturaIptal() {
    if (confirm('Faturayı iptal etmek istediğinize emin misiniz?')) {
        window.location.href = API_BASE + '/cariler.php';
    }
}

document.getElementById('urun-ara').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') urunAra();
});

document.addEventListener('DOMContentLoaded', function() {
    hesaplaToplam();
    odemeSatiriEkle(); // varsayılan olarak bir NAKİT ödeme satırı ile başla
    document.getElementById('fatura-no').addEventListener('input', function() {
        document.getElementById('fatura-no-goster').textContent = this.value;
    });
    document.getElementById('fatura-tarihi').addEventListener('input', function() {
        var date = new Date(this.value);
        document.getElementById('fatura-tarihi-goster').textContent = date.toLocaleDateString('tr-TR');
    });
    document.getElementById('fatura-tipi').addEventListener('change', function() {
        document.getElementById('fatura-tipi-goster').textContent = this.value;
    });
    document.getElementById('fatura-senaryo').addEventListener('change', function() {
        document.getElementById('senaryo-goster').textContent = this.value;
    });
    document.getElementById('fatura-ozellestirme').addEventListener('change', function() {
        document.getElementById('ozellestirme-goster').textContent = this.value;
    });
    document.getElementById('fatura-ettn').addEventListener('input', function() {
        document.getElementById('ettn-goster').textContent = this.value;
    });
});
</script>
JS;
require_once __DIR__ . '/../includes/footer.php';
?>
