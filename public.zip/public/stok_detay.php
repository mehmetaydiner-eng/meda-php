<?php
/**
 * public/stok_detay.php
 *
 * NOT: Bu sayfa orijinal Flask uygulamasında yoktu - kullanıcı isteği
 * üzerine eklendi. Ürünün temel bilgilerini ve YENİ eklenen
 * `stok_hareketleri` defterinden gelen tam hareket geçmişini (hangi
 * satış/alış/iade/servis/manuel düzenlemenin stoğu ne zaman ne kadar
 * değiştirdiğini) gösterir.
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/pagination.php';
require_login();

$id = safe_int($_GET['id'] ?? null);
if (!$id) {
    header('Location: ' . BASE_URL . '/stok_listesi.php');
    exit;
}

$stmt = $pdo->prepare('SELECT * FROM urunler WHERE id = ?');
$stmt->execute([$id]);
$urun = $stmt->fetch();

if (!$urun) {
    http_response_code(404);
    die('Ürün bulunamadı.');
}

$sayfa = get_current_page();
$perPage = 25;

$stmt = $pdo->prepare('SELECT COUNT(*) FROM stok_hareketleri WHERE urun_id = ?');
$stmt->execute([$id]);
$toplamHareket = (int)$stmt->fetchColumn();
$toplamSayfa = (int)ceil($toplamHareket / $perPage);

$stmt = $pdo->prepare(
    'SELECT sh.*, c.unvan AS cari_unvan, c.cari_turu
     FROM stok_hareketleri sh
     LEFT JOIN cariler c ON c.id = sh.cari_id
     WHERE sh.urun_id = :id
     ORDER BY sh.created_at DESC, sh.id DESC LIMIT :limit OFFSET :offset'
);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
$stmt->bindValue(':offset', pagination_offset($sayfa, $perPage), PDO::PARAM_INT);
$stmt->execute();
$hareketler = $stmt->fetchAll();

// Özet istatistikler (tüm geçmiş üzerinden, sadece o anki sayfadan değil)
$stmt = $pdo->prepare("SELECT COALESCE(SUM(miktar),0) FROM stok_hareketleri WHERE urun_id = ? AND miktar > 0");
$stmt->execute([$id]);
$toplamGiris = (float)$stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COALESCE(SUM(miktar),0) FROM stok_hareketleri WHERE urun_id = ? AND miktar < 0");
$stmt->execute([$id]);
$toplamCikis = abs((float)$stmt->fetchColumn());

$page_title   = 'ÜRÜN DETAY';
$breadcrumb   = e($urun['urun_adi']);
$current_page = 'stok_listesi';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="card-custom">
    <div class="card-header-custom">
        <h5><i class="fas fa-box"></i> <?= e($urun['urun_adi']) ?></h5>
        <div>
            <a href="<?= BASE_URL ?>/stok_duzenle.php?id=<?= (int)$urun['id'] ?>" class="btn btn-outline-primary btn-sm">
                <i class="fas fa-edit"></i> DÜZENLE
            </a>
            <a href="<?= BASE_URL ?>/stok_barkod_bas.php?id=<?= (int)$urun['id'] ?>" class="btn btn-outline-info btn-sm">
                <i class="fas fa-barcode"></i> BARKOD
            </a>
            <a href="<?= BASE_URL ?>/stok_listesi.php" class="btn btn-outline-secondary btn-sm">
                <i class="fas fa-arrow-left"></i> GERİ
            </a>
        </div>
    </div>

    <div class="row g-3">
        <?php if (!empty($urun['resim'])): ?>
        <div class="col-md-2 text-center">
            <img src="<?= BASE_URL ?>/assets/uploads/urunler/<?= e($urun['resim']) ?>" alt="<?= e($urun['urun_adi']) ?>"
                 style="max-width: 100%; max-height: 140px; border-radius: 8px; border: 1px solid var(--border-color); object-fit: cover;">
        </div>
        <?php endif; ?>
        <div class="col-md-<?= !empty($urun['resim']) ? '5' : '6' ?>">
            <p><strong>Ürün Kodu:</strong> <?= e($urun['urun_kodu']) ?></p>
            <p><strong>Barkod:</strong> <?= e($urun['barkod'] ?: '-') ?></p>
            <p><strong>Seri No:</strong> <?= e($urun['seri_no'] ?: '-') ?></p>
            <p><strong>Kategori:</strong> <?= e($urun['kategori'] ?: '-') ?></p>
            <p><strong>Birim:</strong> <?= e($urun['birim'] ?: 'ADET') ?></p>
            <p><strong>Ürün Tipi:</strong> <?= e($urun['urun_tipi'] ?: 'SIFIR') ?></p>
        </div>
        <div class="col-md-<?= !empty($urun['resim']) ? '5' : '6' ?>">
            <p><strong>Alış Fiyatı:</strong> <?= number_format((float)$urun['alis_fiyati'], 2, ',', '.') ?> <?= e($urun['alis_fiyati_doviz'] ?: 'TL') ?></p>
            <p><strong>Satış Fiyatı:</strong> <?= number_format((float)$urun['satis_fiyati'], 2, ',', '.') ?> <?= e($urun['satis_fiyati_doviz'] ?: 'TL') ?></p>
            <p><strong>Min. / Max. Stok:</strong> <?= number_format((float)$urun['min_stok'], 0, ',', '.') ?> / <?= number_format((float)$urun['max_stok'], 0, ',', '.') ?></p>
            <p><strong>Mevcut Stok:</strong>
                <span style="font-size: 18px; font-weight: 700; color: <?= (float)$urun['stok_miktari'] <= (float)$urun['min_stok'] ? 'var(--badge-danger-text, #d44a4a)' : 'var(--badge-success-text, #4ad46a)' ?>;">
                    <?= number_format((float)$urun['stok_miktari'], 2, ',', '.') ?> <?= e($urun['birim'] ?: 'ADET') ?>
                </span>
            </p>
        </div>
        <?php if (!empty($urun['aciklama'])): ?>
        <div class="col-12">
            <p><strong>Açıklama:</strong><br><?= nl2br(e($urun['aciklama'])) ?></p>
        </div>
        <?php endif; ?>
    </div>
</div>

<div class="row g-3 mt-1 mb-1">
    <div class="col-md-4">
        <div class="card-custom text-center">
            <h5 class="text-muted">TOPLAM GİRİŞ</h5>
            <h3 class="text-success"><?= number_format($toplamGiris, 2, ',', '.') ?></h3>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card-custom text-center">
            <h5 class="text-muted">TOPLAM ÇIKIŞ</h5>
            <h3 class="text-danger"><?= number_format($toplamCikis, 2, ',', '.') ?></h3>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card-custom text-center">
            <h5 class="text-muted">HAREKET SAYISI</h5>
            <h3 class="text-info"><?= $toplamHareket ?></h3>
        </div>
    </div>
</div>

<div class="card-custom">
    <div class="card-header-custom">
        <h5><i class="fas fa-history"></i> STOK HAREKETLERİ</h5>
    </div>

    <?php if (!$hareketler): ?>
    <div class="alert alert-info">
        <i class="fas fa-info-circle"></i>
        Bu ürün için henüz kayıtlı bir stok hareketi yok. Stok hareketleri
        <?= date('d.m.Y') ?> tarihinden (bu özelliğin eklendiği tarih) itibaren
        kaydedilmeye başlandı - daha önceki değişiklikler için geriye dönük bir
        kayıt bulunmuyor.
    </div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table-custom">
            <thead>
                <tr>
                    <th>Tarih</th>
                    <th>Tür</th>
                    <th class="text-end">Miktar</th>
                    <th class="text-end">Öncesi</th>
                    <th class="text-end">Sonrası</th>
                    <th>Referans</th>
                    <th>Cari</th>
                    <th>Açıklama</th>
                    <th>Kullanıcı</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($hareketler as $h): ?>
                <?php
                    $turClass = match($h['hareket_turu']) {
                        'SATIŞ'  => 'bg-success',
                        'ALIŞ'   => 'bg-info',
                        'İADE'   => 'bg-warning',
                        'SERVİS' => 'bg-primary',
                        'İPTAL'  => 'bg-danger',
                        default  => 'bg-secondary',
                    };
                    $girisMi = (float)$h['miktar'] > 0;
                ?>
                <tr>
                    <td><?= format_tarih($h['created_at'], 'd.m.Y H:i') ?></td>
                    <td><span class="badge-status <?= $turClass ?>"><?= e($h['hareket_turu']) ?></span></td>
                    <td class="text-end <?= $girisMi ? 'text-success' : 'text-danger' ?>">
                        <?= $girisMi ? '+' : '' ?><?= number_format((float)$h['miktar'], 2, ',', '.') ?>
                    </td>
                    <td class="text-end text-muted"><?= number_format((float)$h['stok_oncesi'], 2, ',', '.') ?></td>
                    <td class="text-end"><strong><?= number_format((float)$h['stok_sonrasi'], 2, ',', '.') ?></strong></td>
                    <td><?= e($h['referans_no'] ?: '-') ?></td>
                    <td>
                        <?php if ($h['cari_unvan']): ?>
                            <a href="<?= BASE_URL ?>/cari_detay.php?id=<?= (int)$h['cari_id'] ?>" class="text-decoration-none"><?= e($h['cari_unvan']) ?></a>
                            <?php if ($h['cari_turu'] === 'TEDARİKÇİ'): ?>
                                <span class="badge-status bg-secondary" style="font-size:9px;">TEDARİKÇİ</span>
                            <?php elseif ($h['cari_turu'] === 'MÜŞTERİ'): ?>
                                <span class="badge-status bg-secondary" style="font-size:9px;">MÜŞTERİ</span>
                            <?php endif; ?>
                        <?php else: ?>
                            <span class="text-muted">-</span>
                        <?php endif; ?>
                    </td>
                    <td><?= e($h['aciklama'] ?: '-') ?></td>
                    <td><?= e($h['created_by'] ?: '-') ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?= render_pagination_ozet($sayfa, $perPage, $toplamHareket) ?>
    <?= render_pagination($sayfa, $toplamSayfa, BASE_URL . '/stok_detay.php', ['id' => $id]) ?>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
