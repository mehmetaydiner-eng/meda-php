<?php
/**
 * public/teklif_duzenle.php
 * Teklif düzenleme yönlendiricisi.
 */
require_once __DIR__ . '/../includes/auth.php';
require_login();

$id = safe_int($_GET['id'] ?? null);
if (!$id) {
    header('Location: ' . BASE_URL . '/teklifler.php');
    exit;
}

header('Location: ' . BASE_URL . '/teklif_olustur.php?id=' . $id);
exit;
