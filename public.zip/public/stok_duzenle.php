<?php
require_once __DIR__ . '/../includes/auth.php';
require_login();

$id = safe_int($_GET['id'] ?? null);
if (!$id) {
    header('Location: ' . BASE_URL . '/stok_listesi.php');
    exit;
}

$stmt = $pdo->prepare('SELECT * FROM urunler WHERE id = ?');
$stmt->execute([$id]);
$urun = $stmt->fetch();

if (!$urun) {
    http_response_code(404);
    die('Ürün bulunamadı.');
}

// Efe'nin isteği üzerine (19 Temmuz 2026): kategori artık serbest metin
// değil, kategori_yonetim.php'de tanımlanan listeden bir dropdown. Ürünün
// MEVCUT kategorisi tanımlı listede yoksa (örn. bu özellikten önce serbest
// metin olarak girilmişse), dropdown'da kaybolmaması için listeye ekleniyor.
$kategoriler = $pdo->query('SELECT kategori_adi FROM kategoriler ORDER BY kategori_adi')->fetchAll(PDO::FETCH_COLUMN);
if (!empty($urun['kategori']) && !in_array($urun['kategori'], $kategoriler, true)) {
    $kategoriler[] = $urun['kategori'];
    sort($kategoriler, SORT_STRING | SORT_FLAG_CASE);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf(BASE_URL . '/stok_duzenle.php?id=' . $id);

    $urun_kodu = turkce_upper(trim($_POST['urun_kodu'] ?? ''));
    $urun_adi  = turkce_upper(trim($_POST['urun_adi'] ?? ''));
    $barkod    = trim($_POST['barkod'] ?? '');
    $seri_no   = turkce_upper(trim($_POST['seri_no'] ?? ''));
    $urun_tipi = turkce_upper(trim($_POST['urun_tipi'] ?? 'SIFIR'));
    $kategori  = turkce_upper(trim($_POST['kategori'] ?? ''));
    $birim     = turkce_upper(trim($_POST['birim'] ?? 'ADET'));

    $alis_fiyati        = safe_float($_POST['alis_fiyati'] ?? null);
    $alis_fiyati_doviz  = turkce_upper(trim($_POST['alis_fiyati_doviz'] ?? 'TL'));
    $satis_fiyati       = safe_float($_POST['satis_fiyati'] ?? null);
    $satis_fiyati_doviz = turkce_upper(trim($_POST['satis_fiyati_doviz'] ?? 'TL'));
    $stok_miktari       = safe_float($_POST['stok_miktari'] ?? null);
    $min_stok           = safe_float($_POST['min_stok'] ?? null);
    $max_stok           = safe_float($_POST['max_stok'] ?? null);
    $aciklama           = turkce_upper(trim($_POST['aciklama'] ?? ''));

    $update = $pdo->prepare(
        'UPDATE urunler SET urun_kodu=?, urun_adi=?, barkod=?, seri_no=?, urun_tipi=?, kategori=?, birim=?,
         alis_fiyati=?, alis_fiyati_doviz=?, satis_fiyati=?, satis_fiyati_doviz=?,
         stok_miktari=?, min_stok=?, max_stok=?, aciklama=?, updated_at=datetime(\'now\',\'localtime\') WHERE id=?'
    );
    $update->execute([
        $urun_kodu, $urun_adi, $barkod, $seri_no, $urun_tipi, $kategori, $birim,
        $alis_fiyati, $alis_fiyati_doviz, $satis_fiyati, $satis_fiyati_doviz,
        $stok_miktari, $min_stok, $max_stok, $aciklama, $id,
    ]);

    // Stok miktarı elle değiştirildiyse (sadece başka bir alan değil), bunu
    // da bir "MANUEL" defter satırı olarak kaydediyoruz - aksi halde stok
    // hareketleri geçmişinde açıklanamayan bir sıçrama görünürdü.
    $eskiStok = (float)$urun['stok_miktari'];
    if (abs($eskiStok - $stok_miktari) > 0.0001) {
        stok_hareketi_ekle(
            $pdo, $id, 'MANUEL', $stok_miktari - $eskiStok,
            $eskiStok, $stok_miktari, null, 'Ürün düzenleme ekranından manuel değiştirildi'
        );
    }

    // Resim kaldırma işaretlendiyse eski dosyayı sil
    if (!empty($_POST['resim_kaldir'])) {
        urun_resim_sil($urun['resim']);
        $pdo->prepare('UPDATE urunler SET resim = NULL WHERE id = ?')->execute([$id]);
    }

    // Yeni bir resim yüklendiyse (varsa eskisinin üzerine yaz)
    if (!empty($_FILES['urun_resmi']['name'])) {
        $yukleSonuc = urun_resim_yukle($_FILES['urun_resmi'], $id);
        if ($yukleSonuc['success'] && $yukleSonuc['filename']) {
            urun_resim_sil($urun['resim']); // eski resmi temizle
            $pdo->prepare('UPDATE urunler SET resim = ? WHERE id = ?')->execute([$yukleSonuc['filename'], $id]);
        } elseif (!$yukleSonuc['success']) {
            flash_set($urun_adi . ' güncellendi, ama resim yüklenemedi: ' . $yukleSonuc['message'], 'warning');
            header('Location: ' . BASE_URL . '/stok_listesi.php');
            exit;
        }
    }

    flash_set($urun_adi . ' güncellendi!', 'success');
    header('Location: ' . BASE_URL . '/stok_listesi.php');
    exit;
}

$page_title   = 'ÜRÜN DÜZENLE';
$breadcrumb   = 'Ürün Düzenleme';
$current_page = 'stok_duzenle';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-10">
        <div class="card-custom">
            <div class="card-header-custom">
                <h5><i class="fas fa-edit"></i> ÜRÜN DÜZENLE - <?= e($urun['urun_adi']) ?></h5>
                <div>
                    <a href="<?= BASE_URL ?>/stok_detay.php?id=<?= (int)$urun['id'] ?>" class="btn btn-outline-success btn-sm">
                        <i class="fas fa-history"></i> STOK HAREKETLERİ
                    </a>
                    <a href="<?= BASE_URL ?>/stok_barkod_bas.php?id=<?= (int)$urun['id'] ?>" class="btn btn-outline-info btn-sm">
                        <i class="fas fa-barcode"></i> BARKOD YAZDIR
                    </a>
                    <a href="<?= BASE_URL ?>/stok_listesi.php" class="btn btn-outline-primary btn-sm">
                        <i class="fas fa-arrow-left"></i> GERİ
                    </a>
                </div>
            </div>

            <form method="POST" enctype="multipart/form-data">
                <?= csrf_field() ?>                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">ÜRÜN KODU <span class="text-danger">*</span></label>
                        <input type="text" name="urun_kodu" class="form-control" value="<?= e($urun['urun_kodu']) ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">ÜRÜN ADI <span class="text-danger">*</span></label>
                        <input type="text" name="urun_adi" class="form-control" value="<?= e($urun['urun_adi']) ?>" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">BARKOD</label>
                        <div class="input-group">
                            <input type="text" name="barkod" id="barkod" class="form-control" value="<?= e($urun['barkod'] ?? '') ?>">
                            <button type="button" class="btn btn-outline-primary" onclick="barkodOlustur()">
                                <i class="fas fa-qrcode"></i> OLUŞTUR
                            </button>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">SERİ NUMARASI</label>
                        <input type="text" name="seri_no" class="form-control" value="<?= e($urun['seri_no'] ?? '') ?>">
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">
                            KATEGORİ
                            <a href="<?= BASE_URL ?>/kategori_yonetim.php" target="_blank" style="font-size: 11px;" title="Yeni kategori tanımla">
                                <i class="fas fa-plus-circle"></i> Kategori Ekle/Yönet
                            </a>
                        </label>
                        <select name="kategori" class="form-select">
                            <option value="">-- Kategori Seçin --</option>
                            <?php foreach ($kategoriler as $kat): ?>
                                <option value="<?= e($kat) ?>" <?= ($urun['kategori'] ?? '') === $kat ? 'selected' : '' ?>><?= e($kat) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">BİRİM</label>
                        <select name="birim" class="form-select">
                            <?php foreach (['ADET','KG','METRE','LİTRE','SAAT','PAKET','KUTU'] as $b): ?>
                                <option value="<?= $b ?>" <?= $urun['birim'] === $b ? 'selected' : '' ?>><?= $b ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">ÜRÜN TİPİ</label>
                        <select name="urun_tipi" class="form-select">
                            <option value="SIFIR" <?= $urun['urun_tipi'] === 'SIFIR' ? 'selected' : '' ?>>SIFIR</option>
                            <option value="2.EL" <?= $urun['urun_tipi'] === '2.EL' ? 'selected' : '' ?>>2.EL</option>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">ALIŞ FİYATI</label>
                        <div class="input-group">
                            <input type="number" name="alis_fiyati" class="form-control" step="0.01" value="<?= e((string)$urun['alis_fiyati']) ?>">
                            <select name="alis_fiyati_doviz" class="form-select" style="max-width: 80px;">
                                <?php foreach (['TL','USD','EUR'] as $d): ?>
                                    <option value="<?= $d ?>" <?= $urun['alis_fiyati_doviz'] === $d ? 'selected' : '' ?>><?= $d ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">SATIŞ FİYATI</label>
                        <div class="input-group">
                            <input type="number" name="satis_fiyati" class="form-control" step="0.01" value="<?= e((string)$urun['satis_fiyati']) ?>">
                            <select name="satis_fiyati_doviz" class="form-select" style="max-width: 80px;">
                                <?php foreach (['TL','USD','EUR'] as $d): ?>
                                    <option value="<?= $d ?>" <?= $urun['satis_fiyati_doviz'] === $d ? 'selected' : '' ?>><?= $d ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">STOK MİKTARI</label>
                        <input type="number" name="stok_miktari" class="form-control" step="0.01" value="<?= e((string)$urun['stok_miktari']) ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">MIN. STOK</label>
                        <input type="number" name="min_stok" class="form-control" step="0.01" value="<?= e((string)$urun['min_stok']) ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">MAX. STOK</label>
                        <input type="number" name="max_stok" class="form-control" step="0.01" value="<?= e((string)$urun['max_stok']) ?>">
                    </div>

                    <div class="col-md-12">
                        <label class="form-label">ÜRÜN RESMİ</label>
                        <?php if (!empty($urun['resim'])): ?>
                            <div class="d-flex align-items-center gap-3 mb-2">
                                <img src="<?= BASE_URL ?>/assets/uploads/urunler/<?= e($urun['resim']) ?>" alt="Ürün Resmi" style="max-width: 120px; max-height: 120px; border-radius: 6px; border: 1px solid var(--border-color);">
                                <label class="d-flex align-items-center gap-1" style="font-size: 12px;">
                                    <input type="checkbox" name="resim_kaldir" value="1"> Resmi kaldır
                                </label>
                            </div>
                        <?php endif; ?>
                        <input type="file" name="urun_resmi" class="form-control" accept="image/jpeg,image/png,image/webp,image/gif">
                        <small class="text-muted">JPG, PNG, WEBP ya da GIF - maksimum 3 MB. Yeni bir dosya seçersen mevcut resmin yerine geçer.</small>
                    </div>

                    <div class="col-md-12">
                        <label class="form-label">AÇIKLAMA</label>
                        <textarea name="aciklama" class="form-control" rows="3"><?= e($urun['aciklama'] ?? '') ?></textarea>
                    </div>
                </div>

                <div class="mt-4">
                    <button type="submit" class="btn btn-success-custom">
                        <i class="fas fa-save"></i> GÜNCELLE
                    </button>
                    <a href="<?= BASE_URL ?>/stok_listesi.php" class="btn btn-outline-primary">İPTAL</a>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
$extra_js = <<<'JS'
<script>
function barkodOlustur() {
    var prefix = '869';
    var random = '';
    for (var i = 0; i < 9; i++) {
        random += Math.floor(Math.random() * 10);
    }
    var check = Math.floor(Math.random() * 10);
    var barkod = prefix + random + check;
    document.getElementById('barkod').value = barkod;
}
</script>
JS;
require_once __DIR__ . '/../includes/footer.php';
?>
