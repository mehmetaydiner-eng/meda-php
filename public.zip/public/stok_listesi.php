<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/pagination.php';
require_login();

$sayfa = get_current_page();
$perPage = 30;

$toplam_urun = (int)$pdo->query('SELECT COUNT(*) FROM urunler')->fetchColumn();
$toplam_sayfa = (int)ceil($toplam_urun / $perPage);
$toplam_stok = (float)($pdo->query('SELECT SUM(stok_miktari) FROM urunler')->fetchColumn() ?: 0);
$dusuk_stok  = (int)$pdo->query('SELECT COUNT(*) FROM urunler WHERE stok_miktari <= min_stok')->fetchColumn();

$stmt = $pdo->prepare('SELECT * FROM urunler ORDER BY urun_adi LIMIT :limit OFFSET :offset');
$stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
$stmt->bindValue(':offset', pagination_offset($sayfa, $perPage), PDO::PARAM_INT);
$stmt->execute();
$urunler = $stmt->fetchAll();

// NOT: Kategori istatistikleri ve filtre listesi TÜM ürünler üzerinden
// hesaplanmalı (sadece o anki sayfadaki 30 üründen değil) - bu yüzden
// sayfalanmış $urunler listesinden değil, ayrı hafif bir sorgudan alınıyor.
$tumKategoriler = $pdo->query('SELECT kategori FROM urunler')->fetchAll(PDO::FETCH_COLUMN);
$kategoriSayisi = count(array_unique(array_map(fn($k) => $k ?? '', $tumKategoriler)));
$kategoriler = array_values(array_unique(array_filter($tumKategoriler)));
sort($kategoriler, SORT_STRING | SORT_FLAG_CASE);

// Kart popup'ları için ayrı, sayfalanmamış sorgular (her biri en fazla 100
// kayıtla sınırlı - bir "hızlı bakış" raporu olduğu için).
$popup_tumurunler = $pdo->query('SELECT id, urun_kodu, urun_adi, stok_miktari FROM urunler ORDER BY urun_adi')->fetchAll();
$popup_dusukstok  = $pdo->query('SELECT id, urun_kodu, urun_adi, stok_miktari, min_stok FROM urunler WHERE stok_miktari <= min_stok ORDER BY stok_miktari ASC')->fetchAll();
$popup_topstok    = $pdo->query('SELECT id, urun_kodu, urun_adi, stok_miktari FROM urunler ORDER BY stok_miktari DESC')->fetchAll();
$popup_kategoriDagilimi = [];
foreach ($kategoriler as $kat) {
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM urunler WHERE kategori = ?');
    $stmt->execute([$kat]);
    $popup_kategoriDagilimi[] = ['kategori' => $kat, 'adet' => (int)$stmt->fetchColumn()];
}

$page_title   = 'STOK YÖNETİMİ';
$breadcrumb   = 'Ürün Listesi';
$current_page = 'stok_listesi';
require_once __DIR__ . '/../includes/header.php';
?>

<!-- İstatistik Kartları -->
<div class="row g-3 mb-4">
    <div class="col-md-3">
        <div class="card-custom text-center" style="cursor:pointer;" onclick="stokStatPopup('tumurunler')" title="Detayları görmek için tıkla">
            <h5 class="text-muted">TOPLAM ÜRÜN</h5>
            <h2 class="text-white"><?= (int)$toplam_urun ?></h2>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card-custom text-center" style="cursor:pointer;" onclick="stokStatPopup('topstok')" title="Detayları görmek için tıkla">
            <h5 class="text-muted">TOPLAM STOK</h5>
            <h2 class="text-info"><?= number_format($toplam_stok, 0, ',', '.') ?></h2>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card-custom text-center" style="cursor:pointer;" onclick="stokStatPopup('dusukstok')" title="Detayları görmek için tıkla">
            <h5 class="text-muted">DÜŞÜK STOK</h5>
            <h2 class="text-warning"><?= (int)$dusuk_stok ?></h2>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card-custom text-center" style="cursor:pointer;" onclick="stokStatPopup('kategoriler')" title="Detayları görmek için tıkla">
            <h5 class="text-muted">KATEGORİLER</h5>
            <h2 class="text-success"><?= (int)$kategoriSayisi ?></h2>
        </div>
    </div>
</div>

<!-- ===== İSTATİSTİK DETAY POPUP ===== -->
<div class="modal fade" id="stokStatModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="stokStatBaslik">Detay</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div id="stokStatIcerik"></div>
            </div>
        </div>
    </div>
</div>

<script>
var STOK_STAT_VERILERI = {
    tumurunler: <?= json_encode($popup_tumurunler, JSON_UNESCAPED_UNICODE) ?>,
    dusukstok: <?= json_encode($popup_dusukstok, JSON_UNESCAPED_UNICODE) ?>,
    topstok: <?= json_encode($popup_topstok, JSON_UNESCAPED_UNICODE) ?>,
    kategoriler: <?= json_encode($popup_kategoriDagilimi, JSON_UNESCAPED_UNICODE) ?>
};
var STOK_STAT_BASLIKLAR = {
    tumurunler: 'Tüm Ürünler (<?= (int)$toplam_urun ?>)',
    dusukstok: 'Düşük Stoklu Ürünler (<?= (int)$dusuk_stok ?>) - Sipariş Verilmeli',
    topstok: 'En Yüksek Stoklu Ürünler',
    kategoriler: 'Kategoriler (<?= (int)$kategoriSayisi ?>)'
};

function stokStatPopup(anahtar) {
    var veri = STOK_STAT_VERILERI[anahtar];
    document.getElementById('stokStatBaslik').textContent = STOK_STAT_BASLIKLAR[anahtar];

    var icerikEl = document.getElementById('stokStatIcerik');
    if (!veri || veri.length === 0) {
        icerikEl.innerHTML = '<p class="text-muted text-center py-3">Bu kategoride kayıt yok.</p>';
    } else if (anahtar === 'kategoriler') {
        icerikEl.innerHTML = '<div class="list-group">' + veri.map(function(k) {
            return '<div class="list-group-item d-flex justify-content-between align-items-center" style="background:transparent;border-color:var(--border-color);color:var(--text-primary);">' +
                '<span>' + k.kategori + '</span><strong>' + k.adet + ' ürün</strong>' +
                '</div>';
        }).join('') + '</div>';
    } else {
        icerikEl.innerHTML = '<div class="list-group">' + veri.map(function(u) {
            var stokRengi = anahtar === 'dusukstok' ? 'text-danger' : '';
            var ekBilgi = anahtar === 'dusukstok' ? ' / min: ' + u.min_stok : '';
            return '<a href="stok_detay.php?id=' + u.id + '" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center" style="background:transparent;border-color:var(--border-color);color:var(--text-primary);">' +
                '<span>' + u.urun_adi + ' <small class="text-muted">(' + u.urun_kodu + ')</small></span>' +
                '<strong class="' + stokRengi + '">' + u.stok_miktari + ekBilgi + '</strong>' +
                '</a>';
        }).join('') + '</div>';
    }

    var modal = new bootstrap.Modal(document.getElementById('stokStatModal'));
    modal.show();
}
</script>

<!-- Ürün Listesi -->
<div class="card-custom">
    <div class="card-header-custom">
        <h5><i class="fas fa-boxes"></i> ÜRÜN LİSTESİ</h5>
        <div>
            <a href="<?= BASE_URL ?>/stok_ekle.php" class="btn btn-success-custom btn-sm">
                <i class="fas fa-plus"></i> YENİ ÜRÜN
            </a>
            <a href="<?= BASE_URL ?>/kategori_yonetim.php" class="btn btn-outline-secondary btn-sm">
                <i class="fas fa-tags"></i> KATEGORİLER
            </a>
            <button class="btn btn-outline-primary btn-sm" onclick="window.print()">
                <i class="fas fa-print"></i> YAZDIR
            </button>
        </div>
    </div>

    <!-- Arama -->
    <div class="row g-2 mb-3">
        <div class="col-md-6">
            <div class="input-group">
                <span class="input-group-text" style="background: #121212; border: 1px solid #2a2a2a; color: #6a6a6a;">
                    <i class="fas fa-search"></i>
                </span>
                <input type="text" id="stokArama" class="form-control" placeholder="ÜRÜN ADI, BARKOD VEYA SERİ NO İLE ARA...">
            </div>
        </div>
        <div class="col-md-3">
            <select id="kategoriFiltre" class="form-select">
                <option value="">TÜM KATEGORİLER</option>
                <?php foreach ($kategoriler as $kat): ?>
                    <option value="<?= e($kat) ?>"><?= e($kat) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-3">
            <button class="btn btn-primary-custom w-100" onclick="stokAra()">
                <i class="fas fa-search"></i> ARA
            </button>
        </div>
    </div>

    <!-- Tablo -->
    <div class="table-responsive">
        <table class="table-custom" id="stokTable">
            <thead>
                <tr>
                    <th style="width: 30px;">#</th>
                    <th style="width: 50px;">RESİM</th>
                    <th>ÜRÜN KODU</th>
                    <th>ÜRÜN ADI</th>
                    <th>BARKOD</th>
                    <th>SERİ NO</th>
                    <th>TİP</th>
                    <th>STOK</th>
                    <th>SATIŞ FİYATI</th>
                    <th style="width: 180px;">İŞLEMLER</th>
                </tr>
            </thead>
            <tbody id="stokTableBody">
                <?php if ($urunler): ?>
                    <?php foreach ($urunler as $i => $urun): ?>
                    <?php
                        $tipClass = $urun['urun_tipi'] === 'SIFIR' ? 'bg-success' : ($urun['urun_tipi'] === '2.EL' ? 'bg-warning' : 'bg-secondary');
                        $stokMiktari = (float)$urun['stok_miktari'];
                        $minStok = (float)$urun['min_stok'];
                        $stokClass = $stokMiktari <= $minStok ? 'text-danger' : ($stokMiktari <= $minStok * 2 ? 'text-warning' : 'text-success');
                    ?>
                    <tr>
                        <td><?= $i + 1 ?></td>
                        <td>
                            <?php if (!empty($urun['resim'])): ?>
                                <img src="<?= BASE_URL ?>/assets/uploads/urunler/<?= e($urun['resim']) ?>" alt="" style="width: 36px; height: 36px; object-fit: cover; border-radius: 4px; border: 1px solid var(--border-color);">
                            <?php else: ?>
                                <div style="width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; border-radius: 4px; background: var(--bg-input); color: var(--text-muted);">
                                    <i class="fas fa-image" style="font-size: 14px;"></i>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td><strong><?= e($urun['urun_kodu']) ?></strong></td>
                        <td>
                            <a href="<?= BASE_URL ?>/stok_detay.php?id=<?= (int)$urun['id'] ?>" class="text-decoration-none" title="Stok Hareketlerini Görüntüle">
                                <?= e($urun['urun_adi']) ?>
                            </a>
                            <?php if (!empty($urun['kategori'])): ?>
                                <br><small class="text-muted"><?= e($urun['kategori']) ?></small>
                            <?php endif; ?>
                        </td>
                        <td><?= $urun['barkod'] ? e($urun['barkod']) : '<span class="text-muted">-</span>' ?></td>
                        <td><?= e($urun['seri_no'] ?: '-') ?></td>
                        <td><span class="badge-status <?= $tipClass ?>"><?= e($urun['urun_tipi'] ?: 'SIFIR') ?></span></td>
                        <td>
                            <span class="<?= $stokClass ?>"><?= number_format($stokMiktari, 0, ',', '.') ?></span>
                            <?= e($urun['birim']) ?>
                        </td>
                        <td>
                            <?= number_format((float)$urun['satis_fiyati'], 2, '.', '') ?>
                            <small class="text-muted"><?= e($urun['satis_fiyati_doviz'] ?: 'TL') ?></small>
                        </td>
                        <td>
                            <div class="btn-group btn-group-sm">
                                <a href="<?= BASE_URL ?>/stok_duzenle.php?id=<?= (int)$urun['id'] ?>" class="btn btn-outline-primary" title="DÜZENLE">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="<?= BASE_URL ?>/stok_barkod_bas.php?id=<?= (int)$urun['id'] ?>" class="btn btn-outline-info" title="BARKOD YAZDIR">
                                    <i class="fas fa-barcode"></i>
                                </a>
                                <a href="<?= BASE_URL ?>/stok_barkod_olustur.php?id=<?= (int)$urun['id'] ?>&csrf_token=<?= urlencode(csrf_token()) ?>" class="btn btn-outline-success" title="BARKOD OLUŞTUR">
                                    <i class="fas fa-qrcode"></i>
                                </a>
                                <a href="<?= BASE_URL ?>/stok_sil.php?id=<?= (int)$urun['id'] ?>&csrf_token=<?= urlencode(csrf_token()) ?>" class="btn btn-outline-danger" title="SİL"
                                   onclick="return confirm('<?= e($urun['urun_adi']) ?> SİLMEK İSTEDİĞİNİZE EMİN MİSİNİZ?')">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="9" class="text-center text-muted py-4">
                            <i class="fas fa-boxes fa-3x d-block mb-3"></i>
                            HENÜZ ÜRÜN EKLENMEMİŞ.<br>
                            <a href="<?= BASE_URL ?>/stok_ekle.php" class="btn btn-success-custom btn-sm mt-2">
                                <i class="fas fa-plus"></i> İLK ÜRÜNÜ EKLE
                            </a>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <?= render_pagination_ozet($sayfa, $perPage, $toplam_urun) ?>
        <?= render_pagination($sayfa, $toplam_sayfa, BASE_URL . '/stok_listesi.php') ?>
    </div>
</div>

<?php
$extra_js = <<<'JS'
<script>
// ========== STOK ARAMA ==========
function stokAra() {
    var q = document.getElementById('stokArama').value.trim();
    var kategori = document.getElementById('kategoriFiltre') ? document.getElementById('kategoriFiltre').value : '';

    var paginationNav = document.querySelector('nav[aria-label="Sayfalama"]');
    if (paginationNav) {
        paginationNav.style.display = (q || kategori) ? 'none' : '';
    }

    var url = 'api/stok_ara.php?';
    if (q) url += 'q=' + encodeURIComponent(q) + '&';
    if (kategori) url += 'kategori=' + encodeURIComponent(kategori);

    fetch(url)
        .then(function(response) { return response.json(); })
        .then(function(data) {
            var tbody = document.getElementById('stokTableBody');
            if (!tbody) return;

            if (data.length === 0) {
                tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted py-4">SONUÇ BULUNAMADI</td></tr>';
                return;
            }

            var html = '';
            data.forEach(function(urun, index) {
                var tipBadge = urun.urun_tipi === 'SIFIR' ? 'bg-success' : 'bg-warning';
                var stokClass = urun.stok_miktari <= urun.min_stok ? 'text-danger' :
                                 (urun.stok_miktari <= urun.min_stok * 2 ? 'text-warning' : 'text-success');

                var resimHtml = urun.resim
                    ? '<img src="assets/uploads/urunler/' + urun.resim + '" alt="" style="width:36px;height:36px;object-fit:cover;border-radius:4px;border:1px solid var(--border-color);">'
                    : '<div style="width:36px;height:36px;display:flex;align-items:center;justify-content:center;border-radius:4px;background:var(--bg-input);color:var(--text-muted);"><i class="fas fa-image" style="font-size:14px;"></i></div>';

                html += '<tr>' +
                    '<td>' + (index + 1) + '</td>' +
                    '<td>' + resimHtml + '</td>' +
                    '<td><strong>' + urun.urun_kodu + '</strong></td>' +
                    '<td><a href="stok_detay.php?id=' + urun.id + '" class="text-decoration-none" title="Stok Hareketlerini Görüntüle">' + urun.urun_adi + '</a>' + (urun.kategori ? '<br><small class="text-muted">' + urun.kategori + '</small>' : '') + '</td>' +
                    '<td>' + (urun.barkod || '-') + '</td>' +
                    '<td>' + (urun.seri_no || '-') + '</td>' +
                    '<td><span class="badge-status ' + tipBadge + '">' + (urun.urun_tipi || 'SIFIR') + '</span></td>' +
                    '<td class="' + stokClass + '">' + urun.stok_miktari + ' ' + urun.birim + '</td>' +
                    '<td>' + Number(urun.satis_fiyati).toFixed(2) + ' <small class="text-muted">' + (urun.satis_fiyati_doviz || 'TL') + '</small></td>' +
                    '<td><div class="btn-group btn-group-sm">' +
                    '<a href="stok_duzenle.php?id=' + urun.id + '" class="btn btn-outline-primary" title="Düzenle"><i class="fas fa-edit"></i></a>' +
                    '<a href="stok_barkod_bas.php?id=' + urun.id + '" class="btn btn-outline-info" title="Barkod Yazdır"><i class="fas fa-barcode"></i></a>' +
                    '<a href="stok_barkod_olustur.php?id=' + urun.id + '&csrf_token=' + encodeURIComponent(CSRF_TOKEN) + '" class="btn btn-outline-success" title="Barkod Oluştur"><i class="fas fa-qrcode"></i></a>' +
                    '<a href="stok_sil.php?id=' + urun.id + '&csrf_token=' + encodeURIComponent(CSRF_TOKEN) + '" class="btn btn-outline-danger" title="Sil" onclick="return confirm(\'' + urun.urun_adi + ' silmek istediğinize emin misiniz?\')"><i class="fas fa-trash"></i></a>' +
                    '</div></td></tr>';
            });
            tbody.innerHTML = html;
        });
}

document.getElementById('stokArama').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        stokAra();
    }
});

document.getElementById('kategoriFiltre').addEventListener('change', stokAra);
</script>
JS;
require_once __DIR__ . '/../includes/footer.php';
?>
