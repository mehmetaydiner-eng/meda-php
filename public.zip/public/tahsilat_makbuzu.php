<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/numara_manager.php';
require_login();

$cariler = $pdo->query('SELECT * FROM cariler ORDER BY unvan')->fetchAll();
$stmt = $pdo->prepare("SELECT * FROM hesaplar WHERE hesap_turu IN ('KASA','BANKA') AND is_active = 1");
$stmt->execute();
$hesaplar = $stmt->fetchAll();

$makbuz_no = NumaraManager::getNext($pdo, 'THM');

$page_title   = 'TAHSİLAT MAKBUZU';
$breadcrumb   = 'Tahsilat Makbuzu Oluştur';
$current_page = 'makbuzlar';
$extra_css    = '<link rel="stylesheet" href="' . BASE_URL . '/assets/css/tahsilat_makbuzu.css">';
require_once __DIR__ . '/../includes/header.php';

$now = new DateTime('now');
?>

<div class="tahsilat-container">
    <div class="card-custom">
        <div class="tahsilat-header">
            <div class="makbuz-bilgi">
                <div class="makbuz-no">TAHSİLAT MAKBUZU</div>
                <div>No: <span id="makbuzNoGoster"><?= e($makbuz_no) ?></span></div>
                <div>Tarih: <?= $now->format('d.m.Y H:i') ?></div>
            </div>
            <div class="makbuz-bilgi text-end">
                <div><strong>Durum:</strong> <span class="badge">OLUŞTURULUYOR</span></div>
                <div><strong>İşlem:</strong> TAHSİLAT</div>
            </div>
        </div>

        <div class="tahsilat-body">
            <form method="POST" action="<?= BASE_URL ?>/tahsilat_makbuzu_kaydet.php" id="tahsilatForm">
                <?= csrf_field() ?>

                <div class="tahsilat-info-card">
                    <div class="card-title"><i class="fas fa-user"></i> CARİ / MÜŞTERİ BİLGİLERİ</div>
                    <div class="row g-3">
                        <div class="col-md-8">
                            <label class="form-label">Cari / Müşteri <span class="text-danger">*</span></label>
                            <select name="cari_id" class="form-select" required onchange="cariSec(this.value)">
                                <option value="">Seçin...</option>
                                <?php foreach ($cariler as $cari): ?>
                                <option value="<?= (int)$cari['id'] ?>"><?= e($cari['unvan']) ?> - <?= e($cari['vergi_no'] ?: 'VERGİ NO YOK') ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Cari Bakiyesi</label>
                            <input type="text" id="cari_bakiye" class="form-control" readonly value="0.00 ₺">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Telefon</label>
                            <input type="text" id="cari_tel" class="form-control" readonly value="-">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Email</label>
                            <input type="text" id="cari_email" class="form-control" readonly value="-">
                        </div>
                    </div>
                </div>

                <div class="tahsilat-info-card">
                    <div class="card-title"><i class="fas fa-hand-holding-usd"></i> TAHSİLAT BİLGİLERİ</div>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Tutar <span class="text-danger">*</span></label>
                            <input type="number" name="tutar" id="tutar" class="form-control tutar-buyuk"
                                   step="0.01" placeholder="0.00" required oninput="tutarGuncelle(this.value)">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Para Birimi</label>
                            <select name="para_birimi" class="form-select">
                                <option value="TRY">TL</option>
                                <option value="USD">USD</option>
                                <option value="EUR">EUR</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Ödeme Türü <span class="text-danger">*</span></label>
                            <select name="odeme_turu" class="form-select" required>
                                <option value="NAKİT">NAKİT</option>
                                <option value="KREDİ KARTI">KREDİ KARTI</option>
                                <option value="BANKA HAVALESİ">BANKA HAVALESİ</option>
                                <option value="EFT">EFT</option>
                                <option value="ÇEK">ÇEK</option>
                                <option value="SENET">SENET</option>
                                <option value="KAPIDA ÖDEME">KAPIDA ÖDEME</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Kasa / Hesap</label>
                            <select name="hesap_id" class="form-select">
                                <option value="">Seçin...</option>
                                <?php foreach ($hesaplar as $hesap): ?>
                                <option value="<?= (int)$hesap['id'] ?>"><?= e($hesap['hesap_adi']) ?> (<?= number_format((float)$hesap['bakiye'], 2, '.', '') ?> <?= e($hesap['para_birimi']) ?>)</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Referans No</label>
                            <input type="text" name="referans_no" class="form-control" placeholder="Fatura No, Sipariş No...">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Tahsilat Tarihi</label>
                            <input type="date" name="tarih" class="form-control" value="<?= $now->format('Y-m-d') ?>">
                        </div>
                        <div class="col-md-12">
                            <label class="form-label">Açıklama</label>
                            <textarea name="aciklama" class="form-control" rows="2" placeholder="Tahsilat açıklaması..."></textarea>
                        </div>
                    </div>
                </div>

                <div class="tahsilat-ozet">
                    <div class="ozet-label">TAHSİLAT TUTARI</div>
                    <div class="ozet-deger" id="tutarGoster">0.00 ₺</div>
                </div>

                <div class="row g-2 mt-3 no-print">
                    <div class="col-md-6">
                        <button type="submit" class="btn-tahsilat-kaydet">
                            <i class="fas fa-save"></i> TAHSİLATI KAYDET
                        </button>
                    </div>
                    <div class="col-md-6">
                        <button type="button" class="btn-tahsilat-yazdir" onclick="window.print()">
                            <i class="fas fa-print"></i> YAZDIR / PDF
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
$api_base_json = json_encode(BASE_URL);
$extra_js = <<<JS
<script>
var API_BASE = {$api_base_json};

function cariSec(id) {
    if (!id) {
        document.getElementById('cari_bakiye').value = '0.00 ₺';
        document.getElementById('cari_tel').value = '-';
        document.getElementById('cari_email').value = '-';
        return;
    }

    fetch(API_BASE + '/api/cari_detay.php?id=' + id)
        .then(function(response) { return response.json(); })
        .then(function(data) {
            var bakiye = parseFloat(data.bakiye) || 0;
            document.getElementById('cari_bakiye').value = bakiye.toFixed(2) + ' ₺';
            document.getElementById('cari_tel').value = data.telefon || '-';
            document.getElementById('cari_email').value = data.email || '-';

            var bakiyeInput = document.getElementById('cari_bakiye');
            var theme = document.documentElement.getAttribute('data-theme');
            if (bakiye > 0) {
                bakiyeInput.style.color = theme === 'light' ? '#28a745' : '#4ad46a';
            } else if (bakiye < 0) {
                bakiyeInput.style.color = theme === 'light' ? '#dc3545' : '#d44a4a';
            } else {
                bakiyeInput.style.color = 'var(--text-primary, #e0e0e0)';
            }
        })
        .catch(function(error) { console.error('Hata:', error); });
}

function tutarGuncelle(deger) {
    var tutar = parseFloat(deger) || 0;
    document.getElementById('tutarGoster').textContent = tutar.toFixed(2) + ' ₺';
}

document.addEventListener('DOMContentLoaded', function() {
    var observer = new MutationObserver(function() {
        var theme = document.documentElement.getAttribute('data-theme');
        var bakiyeInput = document.getElementById('cari_bakiye');
        if (bakiyeInput) {
            var bakiyeText = bakiyeInput.value.replace(' ₺', '');
            var bakiye = parseFloat(bakiyeText) || 0;
            if (bakiye > 0) {
                bakiyeInput.style.color = theme === 'light' ? '#28a745' : '#4ad46a';
            } else if (bakiye < 0) {
                bakiyeInput.style.color = theme === 'light' ? '#dc3545' : '#d44a4a';
            } else {
                bakiyeInput.style.color = 'var(--text-primary, #e0e0e0)';
            }
        }
    });

    observer.observe(document.documentElement, {
        attributes: true,
        attributeFilter: ['data-theme']
    });
});
</script>
JS;
require_once __DIR__ . '/../includes/footer.php';
?>
