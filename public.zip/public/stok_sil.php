<?php
require_once __DIR__ . '/../includes/auth.php';
require_login();
require_csrf(BASE_URL . '/stok_listesi.php');

$id = safe_int($_GET['id'] ?? null);
if (!$id) {
    header('Location: ' . BASE_URL . '/stok_listesi.php');
    exit;
}

$stmt = $pdo->prepare('SELECT * FROM urunler WHERE id = ?');
$stmt->execute([$id]);
$urun = $stmt->fetch();

if (!$urun) {
    http_response_code(404);
    die('Ürün bulunamadı.');
}

// Bu ürüne ait fatura detayı varsa silme (Flask: urun.fatura_detaylari kontrolü)
$stmt = $pdo->prepare('SELECT COUNT(*) FROM fatura_detaylari WHERE urun_id = ?');
$stmt->execute([$id]);
$faturaDetaySayisi = (int)$stmt->fetchColumn();

if ($faturaDetaySayisi > 0) {
    flash_set($urun['urun_adi'] . ' silinemez! Bu ürüne ait faturalar var.', 'danger');
    header('Location: ' . BASE_URL . '/stok_listesi.php');
    exit;
}

$delete = $pdo->prepare('DELETE FROM urunler WHERE id = ?');
$delete->execute([$id]);

urun_resim_sil($urun['resim'] ?? null);

flash_set($urun['urun_adi'] . ' silindi!', 'success');
header('Location: ' . BASE_URL . '/stok_listesi.php');
exit;
